cd host_lib-master/python
python3 main.py -t KL520-cam_dme_serial_post_host_yolo
