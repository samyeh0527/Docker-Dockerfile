cd 100_520_PY_To_Taipei_From_Github/host_lib-master/python
python3 main.py -t KL520-cam_dme_serial_post_host_yolo
