"""
This is the example for dme ssd fd single test.
"""
from common import constants, kdp_wrapper
from common.pre_post_process.yolo.yolo_postprocess import yolo_postprocess_


# NJ
import os
import cv2
import time
import sys

# From Mars
from datetime import datetime
import json
import csv


##################################################
# copy From Mars
#"""
def json_file_write(people_count, mask_cnt, folderName = "./tmp/"):
    gm_time = time.gmtime()
    transfer_time_stamp = time.mktime(gm_time)
    formatted_datetime = int(transfer_time_stamp)
	
    data = {
        "timestamp": formatted_datetime,
        "people_count": people_count,
        "mask_people": mask_cnt
    }
    
    json_data = json.dumps(data)
    print('json_data : ', json_data)
    #### save json file to folder ####
    with open(folderName + 'AIVideo_RealTimeImage.json', "w+") as f:
        json.dump(data, f)
    return(json_data)
#"""
################################################



def user_test_single_dme(dev_idx, loop):
    """Test single dme."""
    # model_file = "../input_models/KL520/tiny_yolo_v3/models_520.nef"
    # model_file = "../input_models/KL520/tiny_yolo_v3/models_520_v2_19.nef"
    model_file = "../input_models/KL520/tiny_yolo_v3/models_520_pwmfd_v_15_2_19.nef"
    
    model_id = constants.ModelType.TINY_YOLO_V3_224_224_3.value
    # image_cfg = (constants.IMAGE_FORMAT_SUB128 | constants.NPU_FORMAT_RGB565 |
    #                constants.IMAGE_FORMAT_RAW_OUTPUT)
    
    image_cfg = (constants.IMAGE_FORMAT_RIGHT_SHIFT_ONE_BIT | constants.NPU_FORMAT_RGB565 |
                    constants.IMAGE_FORMAT_RAW_OUTPUT)
    

    # Load model into Kneron device.
    dme_config = kdp_wrapper.init_dme_config(model_id, 2, image_cfg)
    ret = kdp_wrapper.dme_load_model(dev_idx, model_file, dme_config)
    if ret == -1:
        return -1

    image_source_h = 480
    image_source_w = 640
    image_size = image_source_w * image_source_h * 2
    frames = []
    app_id = 0 # if app_id is 0, output raw data for kdp_wrapper.kdp_dme_inference

    # the parameters for postprocess
    anchor_path = './common/pre_post_process/yolo/models/anchors_tiny_v3.txt'
    class_path = './common/class_lists/coco_name_lists'
    # model_input_shape = (224, 224)
    model_input_shape = (416, 416)
    score_thres = 0.2
    nms_thres = 0.45
    keep_aspect_ratio = True

    # Setup video capture device.
    url = "http://admin:@192.168.50.121/video.cgi?.mjpg"
    capture = kdp_wrapper.setup_capture(url, image_source_w, image_source_h)

    if capture is None:
        print("NJ: create captrue fail")
        return -1

        
    # Perform inference and draw result for each capture frame.
    # original load camera
    folderName = "//tmp/"
    while capture.isOpened():
        raw_res = kdp_wrapper.dme_inference(
            dev_idx, 0, capture, model_id, app_id, image_size, frames)
        if raw_res is None:
            print("something happened! maybe check wifi")
            return -1

        dets = yolo_postprocess_(raw_res, anchor_path, class_path, image_source_h, image_source_w,
                                 model_input_shape, score_thres, nms_thres, keep_aspect_ratio)
        
        # print("dets: ", dets)
        jsonFiles = os.listdir(folderName)
        if "AIVideo_RealTimeImage.json" not in jsonFiles:
            print("no json file, save json file")
            faceCount = 0
            maskCount = 0
            for det in dets:
                if det[5] == 0:
                    maskCount += 1
                else:
                    faceCount += 1
            json_file_write(faceCount + maskCount, maskCount, folderName)
        else:
            print("json file exist...")
    
    print("something happened! maybe check wifi")
    
    return 0

def user_test(dev_idx, _user_id):
    # DME test
    ret = user_test_single_dme(dev_idx, 1000)
    kdp_wrapper.end_det(dev_idx)
    return ret

