Copy the app binaries in ota/ready_to_load

ssd_fd_lm:             support ssd_fd_lm applications (ISI/DME)
tiny_yolo_v3(default): support tiny_yolo_v3 applications (ISI/DME) and other DME applications