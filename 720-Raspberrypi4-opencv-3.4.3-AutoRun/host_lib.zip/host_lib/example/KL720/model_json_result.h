/**
 * @file        model_json_result.h
 * @brief       
 * @version     0.1
 * @date        2021-04-22
 *
 * @copyright   Copyright (c) 2021 Kneron Inc. All rights reserved.
 */

#ifndef __MODEL_JSON_RESULT_H__
#define __MODEL_JSON_RESULT_H__


#include "model_type.h"

typedef struct model_map {
    char *name;
    enum model_type model_id;
} model_map_t;

model_map_t k_models[] = {
    {
        .name        = (char*)"invalid_type",
        .model_id    = INVALID_ID,
    },
    {
        .name        = (char*)"kneron_fd_smallbox_200_200_3",
        .model_id    = KNERON_FD_SMALLBOX_200_200_3,
    },
    {
        .name        = (char*)"kneron_fd_anchor_200_200_3",
        .model_id    = KNERON_FD_ANCHOR_200_200_3,
    },
    {
        .name        = (char*)"kneron_fd_mbssd_200_200_3",
        .model_id    = KNERON_FD_MBSSD_200_200_3,
    },
    {
        .name        = (char*)"average_pooling",
        .model_id    = AVERAGE_POOLING,
    },    
    {
        .name        = (char*)"kneron_lm_5pts_onet_56_56_3",
        .model_id    = KNERON_LM_5PTS_ONET_56_56_3,
    },
    {
        .name        = (char*)"kneron_lm_68pts_dlib_112_112_3",
        .model_id    = KNERON_LM_68PTS_dlib_112_112_3,
    },
    {
        .name        = (char*)"kneron_lm_150pts",
        .model_id    = KNERON_LM_150PTS,
    },
    {
        .name        = (char*)"kneron_fr_res50_112_112_3",
        .model_id    = KNERON_FR_RES50_112_112_3,
    },
    {
        .name        = (char*)"kneron_fr_res34",
        .model_id    = KNERON_FR_RES34,
    },
    {
        .name        = (char*)"kneron_fr_vgg10",
        .model_id    = KNERON_FR_VGG10,
    },
    {
        .name        = (char*)"kneron_tiny_yolo_person_416_416_3",
        .model_id    = KNERON_TINY_YOLO_PERSON_416_416_3,
    },
    {
        .name        = (char*)"kneron_3d_liveness",
        .model_id    = KNERON_3D_LIVENESS,
    },
    {
        .name        = (char*)"kneron_3d_liveness",
        .model_id    = KNERON_GESTURE_RETINANET_320_320_3,
    },   
    {
        .name        = (char*)"tiny_yolo_voc_224_224_3",
        .model_id    = TINY_YOLO_VOC_224_224_3,
    },
    {
        .name        = (char*)"imagenet_classification_res50_224_224_3",
        .model_id    = IMAGENET_CLASSIFICATION_RES50_224_224_3,
    },
    {
        .name        = (char*)"imagenet_classification_res34_224_224_3",
        .model_id    = IMAGENET_CLASSIFICATION_RES34_224_224_3,
    },
    {
        .name        = (char*)"imagenet_classification_inception_v3_224_224_3",
        .model_id    = IMAGENET_CLASSIFICATION_INCEPTION_V3_224_224_3,
    },
    {
        .name        = (char*)"imagenet_classification_mobilenet_v2_224_224_3",
        .model_id    = IMAGENET_CLASSIFICATION_MOBILENET_V2_224_224_3,
    },
    {
        .name        = (char*)"tiny_yolo_v3_224_224_3",
        .model_id    = TINY_YOLO_V3_224_224_3,
    },
    {
        .name        = (char*)"kneron_2d_liveness_224_224_3",
        .model_id    = KNERON_2D_LIVENESS_224_224_3,
    },
    {
        .name        = (char*)"kneron_fd_retinanet_256_256_3",
        .model_id    = KNERON_FD_RETINANET_256_256_3,
    },
    {
        .name        = (char*)"kneron_person_mobilenetssd_224_224_3",
        .model_id    = KNERON_PERSON_MOBILENETSSD_224_224_3,
    },
    {
        .name        = (char*)"kneron_age_gender",
        .model_id    = KNERON_AGE_GENDER,
    },
    {
        .name        = (char*)"kneron_lm_5pts_blur_onet_48_48_3",
        .model_id    = KNERON_LM_5PTS_BLUR_ONET_48_48_3,
    },
    {
        .name        = (char*)"kneron_2d_liveness_v3_facebagnet_224_224_3",
        .model_id    = KNERON_2D_LIVENESS_V3_FACEBAGNET_224_224_3,
    },  
    {
        .name        = (char*)"kneron_age_gender_v2_res18_128_128_3",
        .model_id    = KNERON_AGE_GENDER_V2_RES18_128_128_3,
    },                  	
    {
        .name        = (char*)"kneron_od_mbssd",
        .model_id    = KNERON_OD_MBSSD,
    }, 
    {
        .name        = (char*)"kneron_pd_mbssd",
        .model_id    = KNERON_PD_MBSSD,
    },                                    
    {
        .name        = (char*)"kneron_fr_mask_res50_112_112_3",
        .model_id    = KNERON_FR_MASK_RES50_112_112_3,
    },                  
    {
        .name        = (char*)"kneron_nir_liveness_res18_112_112_3",
        .model_id    = KNERON_NIR_LIVENESS_RES18_112_112_3,
    },                  
    {
        .name        = (char*)"kneron_fr_mask_res101_112_112_3",
        .model_id    = KNERON_FR_MASK_RES101_112_112_3,
    },
    {
        .name        = (char*)"kneron_fd_mask_mbssd_200_200_3",
        .model_id    = KNERON_FD_MASK_MBSSD_200_200_3,
    },
    {
        .name        = (char*)"tiny_yolo_v3_416_416_3",
        .model_id    = TINY_YOLO_V3_416_416_3,
    },
    {
        .name        = (char*)"tiny_yolo_v3_608_608_3",
        .model_id    = TINY_YOLO_V3_608_608_3,
    },
    {
        .name        = (char*)"reserver1",
        .model_id    = INVALID_ID,
    },                   
    {
        .name        = (char*)"reserver1",
        .model_id    = INVALID_ID,
    },
    {
        .name        = (char*)"reserver1",
        .model_id    = INVALID_ID,
    },
    {
        .name        = (char*)"reserver1",
        .model_id    = INVALID_ID,
    },
    {
        .name        = (char*)"reserver1",
        .model_id    = INVALID_ID,
    },
    {
        .name        = (char*)"kneron_face_qaulity_onet_56_56_1",
        .model_id    = KNERON_FACE_QAULITY_ONET_56_56_1,
    },
    {
        .name        = (char*)"kneron_fuse_liveness",
        .model_id    = KNERON_FUSE_LIVENESS,
    },
    {
        .name        = (char*)"kneron_eyelid_detection_onet_48_48_3",
        .model_id    = KNERON_EYELID_DETECTION_ONET_48_48_3,
    },
    {
        .name        = (char*)"kneron_yawn_detection_pfld_112_112_3",
        .model_id    = KNERON_YAWN_DETECTION_PFLD_112_112_3,
    },
    {
        .name        = (char*)"kneron_dbface_mbnet_v2_480_864_3",
        .model_id    = KNERON_DBFACE_MBNET_V2_480_864_3,
    },
    {
        .name        = (char*)"kneron_filter",
        .model_id    = KNERON_FILTER,
    },
    {
        .name        = (char*)"kneron_alignment",
        .model_id    = KNERON_ALIGNMENT,
    },
    {
        .name        = (char*)"kneron_face_expression_112_112_3",
        .model_id    = KNERON_FACE_EXPRESSION_112_112_3,
    },
    {
        .name        = (char*)"kneron_rbg_occlusion_res18_112_112_3",
        .model_id    = KNERON_RBG_OCCLUSION_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_lm2bbox",
        .model_id    = KNERON_LM2BBOX,
    },
    {
        .name        = (char*)"kneron_pupil_onet_48_48_3",
        .model_id    = KNERON_PUPIL_ONET_48_48_3,
    },
    {
        .name        = (char*)"kneron_nir_occlusion_res18_112_112_3",
        .model_id    = KNERON_NIR_OCCLUSION_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_head_shoulder_mbnet_v2_112_112_3",
        .model_id    = KNERON_HEAD_SHOULDER_MBNET_V2_112_112_3,
    },
    {
        .name        = (char*)"kneron_rgb_liveness_res18_112_112_3",
        .model_id    = KNERON_RGB_LIVENESS_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_mouth_lm_v1_56_56_1",
        .model_id    = KNERON_MOUTH_LM_v1_56_56_1,
    },
    {
        .name        = (char*)"kneron_mouth_lm_v2_56_56_1",
        .model_id    = KNERON_MOUTH_LM_v2_56_56_1,
    },
    {
        .name        = (char*)"kneron_pupil_onet_48_48_1",
        .model_id    = KNERON_PUPIL_ONET_48_48_1,
    },
    {
        .name        = (char*)"kneron_rgb_liveness_mbv2_112_112_3",
        .model_id    = KNERON_RGB_LIVENESS_MBV2_112_112_3,
    },
    {
        .name        = (char*)"kneron_faceseg_dla34_128_128_3",
        .model_id    = KNERON_FACESEG_DLA34_128_128_3,
    },
    {
        .name        = (char*)"kneron_occ_cls",
        .model_id    = KNERON_OCC_CLS,
    },
    {
        .name        = (char*)"kneron_lmseg_fuse",
        .model_id    = KNERON_LMSEG_FUSE,
    },
    {
        .name        = (char*)"kneron_agegroup_res18_128_128_3",
        .model_id    = KNERON_AGEGROUP_RES18_128_128_3,
    },
    {
        .name        = (char*)"kneron_fr_kface_112_112_3",
        .model_id    = KNERON_FR_kface_112_112_3,
    },
    {
        .name        = (char*)"kneron_fd_rotate_mbssd_200_200_3",
        .model_id    = KNERON_FD_ROTATE_MBSSD_200_200_3,
    },
    {
        .name        = (char*)"kneron_lm_5ptsrotate_onet_56_56_3",
        .model_id    = KNERON_LM_5PTSROTATE_ONET_56_56_3,
    },
    {
        .name        = (char*)"kneron_fuse_liveness_850mm",
        .model_id    = KNERON_FUSE_LIVENESS_850MM,
    },
    {
        .name        = (char*)"kneron_fuse_liveness_940mm",
        .model_id    = KNERON_FUSE_LIVENESS_940MM,
    },
    {
        .name        = (char*)"kneron_face_qaulity_onet_112_112_3",
        .model_id    = KNERON_FACE_QAULITY_ONET_112_112_3,
    },
    {
        .name        = (char*)"kneron_face_pose_onet_56_56_3",
        .model_id    = KNERON_FACE_POSE_ONET_56_56_3,
    },
    {
        .name        = (char*)"kneron_fuse_liveness_850mm_res18_112_112_3",
        .model_id    = KNERON_FUSE_LIVENESS_850MM_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_occclassifer_112_112_3",
        .model_id    = KNERON_OCCCLASSIFER_112_112_3,
    },
    {
        .name        = (char*)"KNERON_FACE_ROTATE_POSE_ONET_56_56_3",
        .model_id    = KNERON_FACE_ROTATE_POSE_ONET_56_56_3,
    },
    {
        .name        = (char*)"kneron_nir_liveness_rot_res18_112_112_3",
        .model_id    = KNERON_NIR_LIVENESS_ROT_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_lm_5pts_onetplus_56_56_3",
        .model_id    = KNERON_LM_5PTS_ONETPLUS_56_56_3,
    },
    {
        .name        = (char*)"kneron_fuse_liveness_940mm_18_res18_112_112_3",
        .model_id    = KNERON_FUSE_LIVENESS_940MM_18_RES18_112_112_3,
    },
    {
        .name        = (char*)"kneron_dbface_mbnet_v2_256_352_3",
        .model_id    = KNERON_DBFACE_MBNET_V2_256_352_3,
    },
#if 0 	
    [76 ... 199] = {  
        .name        = (char*)"reserve1",
        .model_id    = INVALID_ID,
    },
#endif
	//Category Object Detection related 200~300
  //  KNERON_OB_DETECT                                = 200,
    {
        .name        = (char*)"kneron_objectdetection_centernet_512_512_3",
        .model_id    = KNERON_OBJECTDETECTION_CENTERNET_512_512_3,
    },  
    {
        .name        = (char*)"kneron_objectdetection_fcos_416_416_3",
        .model_id    = KNERON_OBJECTDETECTION_FCOS_416_416_3,
    },  
    {
        .name        = (char*)"kneron_pd_mbnet_v2_480_864_3",
        .model_id    = KNERON_PD_MBNET_V2_480_864_3,
    },  
    {
        .name        = (char*)"kneron_car_detection_mbssd_224_416_3",
        .model_id    = KNERON_CAR_DETECTION_MBSSD_224_416_3,
    },  
    {
        .name        = (char*)"kneron_pd_crop_mbssd_304_304_3",
        .model_id    = KNERON_PD_CROP_MBSSD_304_304_3,
    },  
    {
        .name        = (char*)"yolo_v3_416_416_3",
        .model_id    = YOLO_V3_416_416_3,
    },  
    {
        .name        = (char*)"yolo_v4_416_416_3",
        .model_id    = YOLO_V4_416_416_3,
    },  
    {
        .name        = (char*)"kneron_car_detection_yolo_v5_352_640_3",
        .model_id    = KNERON_CAR_DETECTION_YOLO_V5_352_640_3,
    },  
    {
        .name        = (char*)"kneron_license_detect_wpod_208_416_3",
        .model_id    = KNERON_LICENSE_DETECT_WPOD_208_416_3,
    },  
    {
        .name        = (char*)"kneron_2d_upperbody_keypoint_res18_384_288_3",
        .model_id    = KNERON_2D_UPPERBODY_KEYPOINT_RES18_384_288_3,
    },  
    {
        .name        = (char*)"yolo_v3_608_608_3",
        .model_id    = YOLO_V3_608_608_3,
    },  
    {
        .name        = (char*)"kneron_yolov5s_640_640_3",
        .model_id    = KNERON_YOLOV5S_640_640_3,
    },  
    {
        .name        = (char*)"kneron_yolov5s_480_256_3",
        .model_id    = KNERON_YOLOV5S_480_256_3,
    },  
    {
        .name        = (char*)"kneron_sittingposture_resnet34_288_384_3",
        .model_id    = KNERON_SITTINGPOSTURE_RESNET34_288_384_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_fcos_416_416_3",
        .model_id    = KNERON_PERSONDETECTION_FCOS_416_416_3,
    },  
    {
        .name        = (char*)"kneron_yolov5m_640_640_3",
        .model_id    = KNERON_YOLOV5M_640_640_3,
    },  
    {
        .name        = (char*)"kneron_yolov5s6_480_256_3",
        .model_id    = KNERON_YOLOV5S6_480_256_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_fcos_384_288_3",
        .model_id    = KNERON_PERSONDETECTION_FCOS_384_288_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_fcos_720_416_3",
        .model_id    = KNERON_PERSONDETECTION_FCOS_720_416_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_dbface_864_480_3",
        .model_id    = KNERON_PERSONDETECTION_dbface_864_480_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_yolov5s_480_256_3",
        .model_id    = KNERON_PERSONDETECTION_YOLOV5s_480_256_3,
    },  
    {
        .name        = (char*)"kneron_personclassifier_mb_56_32_3",
        .model_id    = KNERON_PERSONCLASSIFIER_MB_56_32_3,
    },  
    {
        .name        = (char*)"kneron_personreid_resnet_42_82_3",
        .model_id    = KNERON_PERSONREID_RESNET_42_82_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_yolov5s_928_512_3",
        .model_id    = KNERON_PERSONDETECTION_YOLOV5s_928_512_3,
    },  
    {
        .name        = (char*)"kneron_upkpts_rsn_256_192_3",
        .model_id    = KNERON_UPKPTS_RSN_256_192_3,
    },  
    {
        .name        = (char*)"kneron_persondetection_yolov5sparklot_480_256_3",
        .model_id    = KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3,
    },  
    {
        .name        = (char*)"kneron_car_detection_mbssd_304_544_3",
        .model_id    = KNERON_CAR_DETECTION_MBSSD_304_544_3,
    },  
    {
        .name        = (char*)"kneron_kptsclassifier_3_11_1",
        .model_id    = KNERON_KPTSCLASSIFIER_3_11_1,
    },  
    {
        .name        = (char*)"kneron_yolov5s3_480_256_3",
        .model_id    = KNERON_YOLOV5S3_480_256_3,
    }, 
#if 0 		
    [229 ... 299] =     
    {
        .name        = (char*)"reserve1",
        .model_id    = INVALID_ID,
    }, 
#endif	
    //Category OCR related 300~400
    {
        .name        = (char*)"kneron_license_ocr_mbnet_64_160_3",
        .model_id    = KNERON_LICENSE_OCR_MBNET_64_160_3,
    },    
    {
        .name        = (char*)"kneron_watermeter_ocr_mbnet",
        .model_id    = KNERON_WATERMETER_OCR_MBNET,
    },    
    {
        .name        = (char*)"kneron_license_ocr_mbnetv2_64_160_3",
        .model_id    = KNERON_LICENSE_OCR_MBNETv2_64_160_3,
    },
#if 0	    
    [303 ... 999] =     
    {
        .name        = (char*)"reserve1",
        .model_id    = INVALID_ID,
    },
#endif	
    //Category SDK test related
    {
        .name        = (char*)"kneron_sdk_fd",
        .model_id    = KNERON_SDK_FD,
    },     
    {
        .name        = (char*)"kneron_sdk_lm(char*)",
        .model_id    = KNERON_SDK_LM,
    },     
    {
        .name        = (char*)"kneron_sdk_fr(char*)",
        .model_id    = KNERON_SDK_FR,
    },     
  
    //Category Customer models
#if 0		
    [1003 ... 32767] =     
    {
        .name        = (char*)"reserve1",
        .model_id    = INVALID_ID,
    },
#endif
    {
        .name        = (char*)"customer_model_1",
        .model_id    = CUSTOMER_MODEL_1,
    },     
   {
        .name        = (char*)"customer_model_2",
        .model_id    = CUSTOMER_MODEL_2,
    },     
    {
        .name        = (char*)"customer_model_3",
        .model_id    = CUSTOMER_MODEL_3,
    },     
    {
        .name        = (char*)"customer_model_4",
        .model_id    = CUSTOMER_MODEL_4,
    },     
    {
        .name        = (char*)"customer_model_5",
        .model_id    = CUSTOMER_MODEL_5,
    },     
    {
        .name        = (char*)"customer_model_6",
        .model_id    = CUSTOMER_MODEL_6,
    },     
    {
        .name        = (char*)"customer_model_7",
        .model_id    = CUSTOMER_MODEL_7,
    },     
    {
        .name        = (char*)"customer_model_8",
        .model_id    = CUSTOMER_MODEL_8,
    },     
    {
        .name        = (char*)"customer_model_9",
        .model_id    = CUSTOMER_MODEL_9,
    },     
};



#endif
