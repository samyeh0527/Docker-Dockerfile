/**
 * @file        user_util.cpp
 * @brief       kdp host lib user test examples
 * @version     0.1
 * @date        2019-07-31
 *
 * @copyright   Copyright (c) 2019-2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"
#include "user_util.h"
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "model_json_result.h"
#if defined (__cplusplus) || defined (c_plusplus)
extern "C"{
#endif
#define EXPORT_RESULT_FILE_DIR ("out_result") 
#define EXPORT_IMAGE_DATA_FILE_DIR ("out_result/%s") 
#define RESULT_FILE                   "result.txt"
extern char* p_ci_logfile_name_g;
volatile uint32_t term_sig = 0;

static int create_out_result_dir(char *path)
{
    DIR* dir = opendir(path);
    int ret = 0;
    if (NULL == dir) {
        if (ENOENT == errno) {

#ifdef __MINGW64__
            if (0 > (ret = mkdir(path))) {
#else
            if (0 > (ret = mkdir(path, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH))) { /* Directory does not exist. */       
#endif
                printf("mkdir failed is %d\r\n", ret);
            }
        }
    }       
    else {
        closedir(dir);
    }    
    return ret;
}

int export_result_to_file(char *out_buf, uint32_t buf_len, char *img, char *res_name)
{
    int ret;
	
    if (0 > (ret = create_out_result_dir((char *)EXPORT_RESULT_FILE_DIR)))
        return ret;
    
    char file_dir[128] = {0};
    
	if ((img == 0) || (NULL == out_buf))
	    return -1;
    if (NULL == res_name)
        res_name = (char *) RESULT_FILE;
    char *p_filename_r = strrchr(img, '/');
   
    if (NULL == p_filename_r) {
        p_filename_r = strrchr(img, '\\');
        if (NULL != p_filename_r) {
            p_filename_r++;
        }
		else
            p_filename_r = img;
    }
    else
    {
        p_filename_r++;
    }    
  
    snprintf(file_dir, 128, EXPORT_IMAGE_DATA_FILE_DIR, p_filename_r);

    if (0 > (ret = create_out_result_dir(file_dir)))
        return ret;
    sprintf(file_dir + strlen(file_dir), "%s", "\\");   
    char *p_result = strcat(file_dir, res_name);
    ret = write_buf_to_file(out_buf, p_result, buf_len);
    memset(out_buf, 0, buf_len);
    
    return ret;
}

static int fill_image_list(struct test_img *img_p, char *dir)
{
    DIR *dp;
    struct dirent *ep;
    static int i = 0;
    if (NULL == (dp = opendir(dir)))
        return -1;
    else
    {
        while (NULL != (ep = readdir(dp))) {
            if (!strncmp(ep->d_name, ".", 1) || !strncmp(ep->d_name, "..", 2))
                continue;
            int dir_name_len = (int) strlen(dir);
            char abs_path_name[128] = {0};
            memcpy(abs_path_name, dir,  dir_name_len);
            strcat(abs_path_name, "/");
            strcat(abs_path_name, ep->d_name);    
             
            struct stat stat_t;
            stat((const char *)abs_path_name, &stat_t);
            
          //  printf("file st_mode %x\r\n",  stat_t.st_mode);
            if (S_ISDIR(stat_t.st_mode)) {
 //               printf("dir name %s\r\n",  abs_path_name);
   
                fill_image_list(img_p,abs_path_name);
            }
            else {
                img_p[i].file_name = (char*)malloc(dir_name_len + strlen(ep->d_name) + 2);
                memset(img_p[i].file_name, 0, dir_name_len + strlen(ep->d_name) + 2);
                memcpy(img_p[i].file_name, abs_path_name, dir_name_len + strlen(ep->d_name) + 1);
                img_p[i].image_size = stat_t.st_size;
                i++;
            }
        }
    }
    closedir(dp);
    return 0;
}    
    
static int count_file_number(char *dir)
{
    DIR *dp;
    struct dirent *ep;
    int file_count = 0;

    if (NULL == (dp = opendir(dir)))
        return -1;
    else
    {
        while (NULL != (ep = readdir(dp))) {
            if (!strncmp(ep->d_name, ".", 1) || !strncmp(ep->d_name, "..", 2))
                continue;
            int dir_name_len = (int) strlen(dir);
            char abs_path_name[128] = {0};
            memcpy(abs_path_name, dir,  dir_name_len);
            strcat(abs_path_name, "/");
            strcat(abs_path_name, ep->d_name);    
            
            struct stat stat_t;
            
            stat((const char *)abs_path_name, &stat_t);
            
          //  printf("file st_mode %x\r\n",  stat_t.st_mode);
            if (S_ISDIR(stat_t.st_mode)) {
                printf("dir name %s\r\n",  abs_path_name);
                
                file_count += count_file_number(abs_path_name);
            }
            else
                file_count++;
        }
    }
    closedir(dp);
    return file_count;
}

test_img_t* create_batch_image_file_list(char *img_or_dir_name, int *total_files)
{
    test_img_t *img_p = NULL;
    struct stat stat_t;
	
	if (img_or_dir_name == NULL)
	    return img_p;
		
    stat((const char *)img_or_dir_name, &stat_t);	
	
    if (S_ISDIR(stat_t.st_mode))
    {
        *total_files = count_file_number((char*)img_or_dir_name);
        if (*total_files == 0)
		    return img_p;
	    img_p = (struct test_img *) malloc((*total_files +1) * sizeof (struct test_img));
        memset(img_p, 0, (*total_files +1) * sizeof (struct test_img));	
        fill_image_list(img_p, (char *)img_or_dir_name);		
    } else if (S_ISREG(stat_t.st_mode)) {
		
		*total_files  = 1;
        img_p = (struct test_img *) malloc(sizeof (struct test_img));
        memset(img_p, 0,  sizeof (struct test_img));
        img_p->file_name = img_or_dir_name;
		img_p->image_size = stat_t.st_size;
		
    }
    return img_p;
}

char* lookup_model_name(uint32_t model_id)
{
    for (int i = 0; i < (int)(sizeof(k_models)/sizeof(k_models[0])); i++)
        if (k_models[i].model_id == model_id)
            return k_models[i].name;
    return NULL;	
}

const char* ci_prepare_logfile_name(int argc, char*argv[])
{
#ifdef KNERON_BUILD_TEST
    int i;
    static std::string filename = argv[0];
    //remove path
    filename = filename.substr(filename.find_last_of("/\\") + 1);
    //remove extention
    std::string::size_type const p(filename.find_last_of('.'));
    filename = filename.substr(0, p);

    for(i=1;i<argc;i++){
        filename += "_";
        filename += argv[i];
    }
    filename += ".log";
    return filename.c_str();
#else
    return NULL;
#endif
}

bool print2log(const char* fmt, ...)
{
#ifdef KNERON_BUILD_TEST
    static FILE* fp = NULL;
    if (NULL == fp) 
        fp = fopen(p_ci_logfile_name_g, "w");
    else
        fp = fopen(p_ci_logfile_name_g, "a");

    if (fp == NULL){
        printf("[error] fail to open file: %s\n", p_ci_logfile_name_g);
        return false;
    }

    char buffer[1024]; 
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, ap);
    va_end(ap);

    fprintf(fp, "%s", buffer);

    fclose(fp);
#endif
    return true;
}

bool check_ctl_break(void)
{

    return  (1 == term_sig);

}

static void sig_term_handler(int signo)
{
    if (0 != ((HOSTLIB_SIG) & signo)) {
        term_sig = 1;
    }
}

int register_hostlib_signal(void) 
{
    if (signal(SIGINT, sig_term_handler) == SIG_IGN)
        signal(SIGINT, SIG_IGN);

    if (signal(SIGTERM, sig_term_handler) == SIG_IGN)
        signal(SIGTERM, SIG_IGN);
    return 0;
}


int write_buf_to_file(char* buf, const char* fn, uint32_t size) {
    if ((NULL == buf) || (NULL == fn)) {
        printf("file name or buffer is null!\n");
        return -1;
    }

    FILE* out = fopen(fn, "wb");
    if (NULL == out) {
        printf("opening file %s failed, error:%s.!\n", fn, strerror(errno));
        return -1;
    }
 
    fwrite (buf , sizeof(char), size, out);
    fclose(out);
    
    return 0;
}

int read_file_to_buf_2(char** buf, const char* fn) {
    if (NULL == fn) {
        printf("file name is null!\n");
        return -1;
    }

    FILE* in = fopen(fn, "rb");
    if (!in) {
        printf("opening file %s failed, error:%s.!\n", fn, strerror(errno));
        return -1;
    }

    fseek(in, 0, SEEK_END);
    long size = ftell(in);  //get the size
 
    *buf = (char *) malloc(size);
    memset(*buf, 0, size);
    fseek(in, 0, SEEK_SET);  //move to begining

    int res = 0;
    while (1) {
        int len = fread(*buf + res, 1, 1024, in);
        if (len == 0) {
            if (!feof(in)) {
                printf("reading from img file failed:%s.!\n", fn);
                fclose(in);
                return -1;
            }
            break;
        }
        res += len;  //calc size
    }
    fclose(in);
    return res;
}

int read_file_to_buf(char* buf, const char* fn, int nlen) {
    if (buf == NULL || fn == NULL) {
        printf("file name or buffer is null!\n");
        return -1;
    }

    FILE* in = fopen(fn, "rb");
    if (!in) {
        printf("opening file %s failed, error:%s.!\n", fn, strerror(errno));
        return -1;
    }

    fseek(in, 0, SEEK_END);
    long f_n = ftell(in);  //get the size
    if (f_n > nlen) {
        printf("buffer is not enough.!\n");
        fclose(in);
        return -1;
    }

    fseek(in, 0, SEEK_SET);  //move to begining

    int res = 0;
    while (1) {
        int len = fread(buf + res, 1, 1024, in);
        if (len == 0) {
            if (!feof(in)) {
                printf("reading from img file failed:%s.!\n", fn);
                fclose(in);
                return -1;
            }
            break;
        }
        res += len;  //calc size
    }
    fclose(in);
    return res;
}

double what_time_is_it_now() {
    struct timeval time;
    if (gettimeofday(&time, NULL)) {
        return 0;
    }
    return (double)time.tv_sec + (double)time.tv_usec * .000001;
}

struct kdp_dme_cfg_s create_dme_cfg_struct() {
    struct kdp_dme_cfg_s dme_cfg;
    memset(&dme_cfg, 0, sizeof(kdp_dme_cfg_s));
    return dme_cfg;
}

struct kdp_isi_cfg_s create_isi_cfg_struct() {
    struct kdp_isi_cfg_s isi_cfg;
    memset(&isi_cfg, 0, sizeof(kdp_isi_cfg_s));
    return isi_cfg;
}

struct kdp_metadata_s create_metadata_struct() {
    struct kdp_metadata_s metadata;
    memset(&metadata, 0, sizeof(kdp_metadata_s));
    return metadata;
}


#define RGB565_TO_B8(rgb565)    ((uint8_t)floor(((rgb565 & 0x001F) >> 0) * 255.0 / 31.0 + 0.5))
#define RGB565_TO_G8(rgb565)    ((uint8_t)floor(((rgb565 & 0x07E0) >> 5) * 255.0 / 63.0 + 0.5))
#define RGB565_TO_R8(rgb565)    ((uint8_t)floor(((rgb565 & 0xF800) >> 11) * 255.0 / 31.0 + 0.5))

#define YCBCR_TO_R8(Y, Cb, Cr)  (((float)Y + 1.402 * (Cr - 128)))
#define YCBCR_TO_G8(Y, Cb, Cr)  (((float)Y - 0.714 * (Cr - 128) - 0.344 * (Cb - 128)))
#define YCBCR_TO_B8(Y, Cb, Cr)  (((float)Y + 1.772 * (Cb - 128)))

#define CLAMP(f)                ((uint8_t)((f > 255.0)? 255.0 : ((f < 0.0)? 0.0 : f)))

#define C4(a, b, c, d)      ((a << 0) | (b << 8) | (c << 16) | (d << 24))

int kdp_cvt_color(void* dst, void* src, int src_len, int fmt2fmt)
{
    uint32_t* dst_data;
    uint8_t     b[4], g[4], r[4];
    uint16_t    tmp;
    int         i, len, rc = 0;

    if (fmt2fmt == RGB565_TO_BGR888) {
        uint16_t* src_data;

        src_data = (uint16_t*)src;
        dst_data = (uint32_t*)dst;
        len = (src_len / 2) / 4;    // in 4 pixels

        for (i = 0; i < len; i++) {
            // Move 4 pixels from image source RGB565 to CV_8UC3/BGR888 frame
            tmp = *src_data++;
            b[0] = RGB565_TO_B8(tmp);
            g[0] = RGB565_TO_G8(tmp);
            r[0] = RGB565_TO_R8(tmp);
            tmp = *src_data++;
            b[1] = RGB565_TO_B8(tmp);
            g[1] = RGB565_TO_G8(tmp);
            r[1] = RGB565_TO_R8(tmp);
            tmp = *src_data++;
            b[2] = RGB565_TO_B8(tmp);
            g[2] = RGB565_TO_G8(tmp);
            r[2] = RGB565_TO_R8(tmp);
            tmp = *src_data++;
            b[3] = RGB565_TO_B8(tmp);
            g[3] = RGB565_TO_G8(tmp);
            r[3] = RGB565_TO_R8(tmp);

            *dst_data++ = C4(b[0], g[0], r[0], b[1]);
            *dst_data++ = C4(g[1], r[1], b[2], g[2]);
            *dst_data++ = C4(r[2], b[3], g[3], r[3]);
        }
    }
    else if (fmt2fmt == YUV422_TO_BGR888) {
        uint8_t     *src_data;
        uint8_t     y0, y1, cr, cb;
        float       tmp;

        src_data = (uint8_t*)src;
        dst_data = (uint32_t*)dst;
        len = (src_len / 2) / 4;    // in 4 pixels

        for (i = 0; i < len; i++) {
            // Move 4 pixels from image source YCbCr to CV_8UC3/BGR888 frame
            y0 = *src_data++;
            cb = *src_data++;
            y1 = *src_data++;
            cr = *src_data++;

            tmp = YCBCR_TO_B8(y0, cb, cr); b[0] = CLAMP(tmp);
            tmp = YCBCR_TO_G8(y0, cb, cr); g[0] = CLAMP(tmp);
            tmp = YCBCR_TO_R8(y0, cb, cr); r[0] = CLAMP(tmp);
            tmp = YCBCR_TO_B8(y1, cb, cr); b[1] = CLAMP(tmp);
            tmp = YCBCR_TO_G8(y1, cb, cr); g[1] = CLAMP(tmp);
            tmp = YCBCR_TO_R8(y1, cb, cr); r[1] = CLAMP(tmp);

            y0 = *src_data++;
            cb = *src_data++;
            y1 = *src_data++;
            cr = *src_data++;

            tmp = YCBCR_TO_B8(y0, cb, cr); b[2] = CLAMP(tmp);
            tmp = YCBCR_TO_G8(y0, cb, cr); g[2] = CLAMP(tmp);
            tmp = YCBCR_TO_R8(y0, cb, cr); r[2] = CLAMP(tmp);
            tmp = YCBCR_TO_B8(y1, cb, cr); b[3] = CLAMP(tmp);
            tmp = YCBCR_TO_G8(y1, cb, cr); g[3] = CLAMP(tmp);
            tmp = YCBCR_TO_R8(y1, cb, cr); r[3] = CLAMP(tmp);

            *dst_data++ = C4(b[0], g[0], r[0], b[1]);
            *dst_data++ = C4(g[1], r[1], b[2], g[2]);
            *dst_data++ = C4(r[2], b[3], g[3], r[3]);
        }
    }
    else {
        printf("Convert format %d not supported\n", fmt2fmt);
        rc = -1;
    }

    return rc;
}


#if defined (__cplusplus) || defined (c_plusplus)
}
#endif
