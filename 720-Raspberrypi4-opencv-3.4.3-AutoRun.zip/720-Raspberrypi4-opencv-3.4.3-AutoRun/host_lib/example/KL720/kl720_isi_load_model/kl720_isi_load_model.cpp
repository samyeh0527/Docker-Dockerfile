/**
 * @file        kl720_isi_load_model.cpp
 * @brief       kdp host lib user test examples
 * @version     0.1
 * @date        2021-2-26
 *
 * @copyright   Copyright (c) 2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "user_util.h"
#include "base.h"
#include "kapp_id.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define NEF_FILE              ("../../app_binaries/KL720/dfu/ready_to_load/models_720.nef")
#define MAX_MODEL_SIZE        (80 * 1024 * 1024)
#define ISI_APP_ID            APP_CENTER_APP
#define ISI_START_DATA_SIZE   1500

char model_file_buffer[MAX_MODEL_SIZE];
static char isi_init_data[ISI_START_DATA_SIZE];

static int load_model_file(int dev_idx, char *nef)
{
    uint32_t error_code = 0;
    uint32_t image_q_size = 0;
    int ret;
    int model_size;
    char* p_buf;
    struct kdp_isi_start_s *isi_init;
    int cfg_size = sizeof(struct kdp_isi_start_s)-sizeof(struct kapp_isi_data_s);

    p_buf = new char[MAX_MODEL_SIZE];
    ret = read_file_to_buf(p_buf, nef, MAX_MODEL_SIZE);
    if (ret <= 0) {
        printf("reading model file failed: %d\n", ret);
        return ret;
    }

    model_size = ret;
    printf("starting loading model ...\n");

    isi_init = (struct kdp_isi_start_s *) isi_init_data;
    memset(isi_init, 0, cfg_size);

    isi_init->app_id = ISI_APP_ID;
    isi_init->compatible_cfg = 0;
    isi_init->start_flag = DOWNLOAD_MODEL;

    ret = kdp_start_isi_mode_ext2(dev_idx, (char*)isi_init_data, cfg_size, p_buf, model_size, &error_code, &image_q_size);
    if (ret != 0) {
        printf("kdp_start_isi_ext2 failed: %d (model_size %d, ret = %d)\n", ret, model_size, ret);
        delete[] p_buf;
        return ret;
    }

    printf("  : done\n");
    delete[] p_buf;
    return 0;
}

int user_test(int dev_idx, char *nef)
{
    int ret;

    double start_time = what_time_is_it_now();

    ret = load_model_file(dev_idx, nef);

    double end_time = what_time_is_it_now();
    double elapsed_time = end_time - start_time;
    printf("=> Time = %.3f seconds\n\n", elapsed_time);

    return ret;
}

static void usage(char *name)
{
    printf("\n");
    printf("usage: %s [nef path]\n", name);
    printf("\n[nef path] default: NEF_FILE, nef path: specified nef path\n");
}

int main(int argc, char *argv[])
{
    int dev_idx = 0;
    kdp_device_info_list_t *list = NULL;
    char *nef;

    if (argc == 1) {
        usage(argv[0]);
        nef = (char *)NEF_FILE;
        printf("\nUse the model file in app_binaries/KL720/dfu/ready_to_load by default\n");
    } else if (argc == 2) {
        nef = (char *)argv[1];
        printf("\nUse the model file: %s\n", nef);
    } else {
        usage(argv[0]);
        return -1;
    }
    printf("init kdp host lib log....\n");

    if (kdp_lib_init() < 0)
    {
        printf("init for kdp host lib failed.\n");
        return -1;
    }

    printf("adding devices....\n");

    kdp_scan_usb_devices(&list);

    for (int i = 0; i < list->num_dev; i++)
    {
        if (list->kdevice[i].product_id == KDP_DEVICE_KL720)
        {
            // found it, now try to connect
            dev_idx = kdp_connect_usb_device(list->kdevice[i].scan_index);
            break;
        }
    }
    free(list);

    if (dev_idx < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    printf("start kdp host lib....\n");
    if (kdp_lib_start() < 0)
    {
        printf("start kdp host lib failed.\n");
        return -1;
    }

    user_test(dev_idx, nef);

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
