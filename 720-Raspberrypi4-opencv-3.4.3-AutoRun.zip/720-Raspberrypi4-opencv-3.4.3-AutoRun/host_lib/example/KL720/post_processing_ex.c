/**
 * @file        post_processing_ex.c
 * @brief       Kneron Example Post-Processing drive
 * @version     0.1
 * @date        2021-03-22
 *
 * @copyright   Copyright (c) 2018-2021 Kneron Inc. All rights reserved.
 */

 
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "stdio.h"
#include "post_processing_ex.h"
#include "base.h"// header file in /common/include
#include "kdpio.h"

/**************************** yolo v3 **************************************/

#define YOLO_V3_O1_GRID_W       7
#define YOLO_V3_O1_GRID_H       7
#define YOLO_V3_O1_GRID_MAX     (YOLO_V3_O1_GRID_W * YOLO_V3_O1_GRID_H)
#define YOLO_V3_O2_GRID_W       14
#define YOLO_V3_O2_GRID_H       14
#define YOLO_V3_O2_GRID_MAX     (YOLO_V3_O2_GRID_W * YOLO_V3_O2_GRID_H)
#define YOLO_V3_CELL_BOX_NUM    3

#define YOLO_CELL_BOX_NUM       5
#define YOLO_CLASS_MAX          80
#define YOLO_BOX_FIX_CH         5   /* x, y, w, h, confidence score */

#define YOLO_MAX_DETECTION_PER_CLASS 100

#define IMAGENET_CLASSES_MAX    1000

#define KDP_COL_MIN             16 /* Bytes, i.e. 128 bits */

//float prob_thresh_yolov3 = 0.3;      // probability threshold for yolo v3
float prob_thresh_yolov3 = 0.15;      // probability threshold for yolo v3
const float nms_thresh_yolov3 = 0.45;      // non max suppression threshold for yolo v3

// For output node with small dimensions (public tiny-yolo-v3)
const float anchers_v0[3][2] = {{81,82}, {135,169}, {344,319}};
// For output node with large dimensions (public tiny-yolo-v3)
const float anchers_v1[3][2] = {{23,27}, {37,58}, {81,82}};

/* Shared global variable area among models */
struct yolo_v3_post_globals_s {
    float box_class_probs[YOLO_CLASS_MAX];
    struct bounding_box_s bboxes_v3[YOLO_GOOD_BOX_MAX];
    struct bounding_box_s result_tmp_s[YOLO_GOOD_BOX_MAX];
};

struct imagenet_post_globals_s {
    struct imagenet_result_s  temp[IMAGENET_CLASSES_MAX];
};

union post_globals_u_s {
    struct yolo_v3_post_globals_s     yolov3;
    struct imagenet_post_globals_s    imgnet;
} u_globals;

static float do_div_scale(float v, int div, float scale)
{
    return ((v / div) / scale);
}

static float do_div_scale_2(float v, float scale)
{
    return (v * scale);
}

uint32_t round_up(uint32_t num){
    return ((num + (KDP_COL_MIN - 1)) & ~(KDP_COL_MIN - 1));
}

static float sigmoid(float x)
{
    float exp_value;
    float return_value;

    exp_value = expf(-x);

    return_value = 1 / (1 + exp_value);

    return return_value;
}

static void softmax(struct imagenet_result_s input[], int input_len)
{
    int i;
    float m;
    
    m = input[0].score;
    for (i = 1; i < input_len; i++) {
        if (input[i].score > m) {
            m = input[i].score;
        }
    }

    float sum = 0;
    for (i = 0; i < input_len; i++) {
        sum += expf(input[i].score - m);
    }

    for (i = 0; i < input_len; i++) {
        input[i].score = expf(input[i].score - m - log(sum));
    }    
}

static int float_comparator(float a, float b)
{
    float diff = a - b;

    if (diff < 0)
        return 1;
    else if (diff > 0)
        return -1;
    return 0;
}

static int box_score_comparator(const void *pa, const void *pb)
{
    float a, b;

    a = ((struct bounding_box_s *)pa)->score;
    b = ((struct bounding_box_s *)pb)->score;

    return float_comparator(a, b);
}

static float overlap(float l1, float r1, float l2, float r2)
{
    float left = l1 > l2 ? l1 : l2;
    float right = r1 < r2 ? r1 : r2;
    return right - left;
}

static float box_intersection(struct bounding_box_s *a, struct bounding_box_s *b)
{
    float w, h, area;

    w = overlap(a->x1, a->x2, b->x1, b->x2);
    h = overlap(a->y1, a->y2, b->y1, b->y2);

    if (w < 0 || h < 0)
        return 0;

    area = w * h;
    return area;
}

static float box_union(struct bounding_box_s *a, struct bounding_box_s *b)
{
    float i, u;

    i = box_intersection(a, b);
    u = (a->y2 - a->y1) * (a->x2 - a->x1) + (b->y2 - b->y1) * (b->x2 - b->x1) - i;

    return u;
}

static float box_iou(struct bounding_box_s *a, struct bounding_box_s *b, int nms_type)
{
    float c = 0.;
    switch (nms_type) {
        case IOU_MIN:
            if (box_intersection(a, b) / box_intersection(a, a) > box_intersection(a, b) / box_intersection(b, b)) {
                c = box_intersection(a, b) / box_intersection(a, a);
            } else {
                c = box_intersection(a, b) / box_intersection(b, b);
            }
            break;
        default:
            if (c < box_intersection(a, b) / box_union(a, b)) {
                c = box_intersection(a, b) / box_union(a, b);
            }
            break;
    }

    return c;
}

#if 1
void bb_scale( struct bounding_box_s *bboxes, int size, int model_w, int model_h, int raw_w, int raw_h, bool keep_ratio )
{
    //printf("size = %d, model: %d, %d, image = %d, %d, keep_ratio = %d\n", size, model_w, model_h, raw_w, raw_h, keep_ratio);
	float ratio_w = (float)model_w / raw_w;
	float ratio_h = (float)model_h / raw_h;
	if(!keep_ratio) {
		ratio_h = ratio_w = (ratio_w < ratio_h) ? ratio_w : ratio_h;
	}
	//float ratio = MIN((float)DIM_INPUT_COL(image_p)/RAW_INPUT_COL(image_p) , DIM_INPUT_ROW(image_p)/RAW_INPUT_ROW(image_p));

	for(int i = 0; i < size; i++) {
		bboxes[i].x2 = (bboxes[i].x2 - bboxes[i].x1) / ratio_w; // w
		bboxes[i].y2 = (bboxes[i].y2 - bboxes[i].y1) / ratio_h; // h

		bboxes[i].x1 /= ratio_w;

		bboxes[i].y1 /= ratio_h;

		bboxes[i].x2 += bboxes[i].x1;

		bboxes[i].y2 += bboxes[i].y1;

		// limit Rectangle

		bboxes[i].x1 = (bboxes[i].x1 > 0) ? bboxes[i].x1 : 0;

		bboxes[i].y1 = (bboxes[i].y1 > 0) ? bboxes[i].y1 : 0;

		bboxes[i].x2 = (bboxes[i].x2 < raw_w) ? bboxes[i].x2 : raw_w;
		bboxes[i].y2 = (bboxes[i].y2 < raw_h) ? bboxes[i].y2 : raw_h;
	}
}
#endif

/**************************** yolo v3 **************************************/
int post_yolo_v3(int model_id, struct kdp_image_s *image_p)
{
    float *ext_param = POSTPROC_PARAMS_P(image_p);
    if ((ext_param) && (*ext_param)) {
        prob_thresh_yolov3 = *ext_param;
    }
    //printf("v3 threshold = %f\n", prob_thresh_yolov3);

    struct yolo_v3_post_globals_s *gp = &u_globals.yolov3;
    int i, j, k, div, ch, row, col, max_score_class, good_box_count, class_good_box_count, good_result_count, len, len_div_4;
    float box_x, box_y, box_w, box_h, box_confidence, max_score;
    int8_t *src_p, *x_p, *y_p, *width_p, *height_p, *score_p, *class_p, *dest_p;
    struct bounding_box_s *bbox;
    struct yolo_result_s *result;
    struct bounding_box_s *result_box_p, *result_tmp_p, *r_tmp_p;

    int data_size, grid_w, grid_h, grid_c, class_num, grid_w_bytes_aligned;
    uint32_t src_img_mode;

    float maxlen = RAW_INPUT_COL(image_p) > RAW_INPUT_ROW(image_p) ? (float)RAW_INPUT_COL(image_p) : (float)RAW_INPUT_ROW(image_p);

    src_img_mode = RAW_FORMAT(image_p);
    data_size = (POSTPROC_OUTPUT_FORMAT(image_p) & BIT(0)) + 1;     /* 1 or 2 in bytes */

    result = (struct yolo_result_s *)(POSTPROC_RESULT_MEM_ADDR(image_p));
    result_box_p = result->boxes;

    result_tmp_p = gp->result_tmp_s;

    class_num = POSTPROC_OUT_NODE_CH(image_p, 0) / YOLO_V3_CELL_BOX_NUM - YOLO_BOX_FIX_CH;

    result->class_count = class_num;
    
    bbox = gp->bboxes_v3;
    good_box_count = 0;

    float anchers_v[3][2];
    int idx;
    int offset = sizeof(struct out_node_s);
    struct out_node_s out_p;

    for (idx = 0; idx < POSTPROC_OUTPUT_NUM(image_p); idx++) {
        out_p = (struct out_node_s)(POSTPROC_OUT_NODE(image_p, idx));

        src_p = (int8_t *)POSTPROC_OUT_NODE_ADDR(image_p, idx);
 
        grid_w = OUT_NODE_COL(out_p);
        grid_h = OUT_NODE_ROW(out_p);
        grid_c = OUT_NODE_CH(out_p);
        len = grid_w * data_size;
        grid_w_bytes_aligned = round_up(len);
        //len = grid_w_bytes_aligned;
        //len_div_4 = len >> 2;
        uint32_t all_data = grid_w_bytes_aligned * (grid_c / 3);
        //dest_p = (int8_t*)malloc(all_data);
        //all_data = all_data >> 2;

        div = 1 << OUT_NODE_RADIX(out_p);
        float fScale = OUT_NODE_SCALE(out_p);
        fScale = 1 / (div * fScale);

        //For tiny yolo v3
        if (0 == idx) {
            memcpy(anchers_v, anchers_v0, 6*sizeof(float));
        } else {
            memcpy(anchers_v, anchers_v1, 6*sizeof(float));
        }

        // Divide the data into half as not enough memory for postprocessing of tiny-yolo-v3-608
        uint32_t all_data_half = all_data >> 1;
        //dest_p = (int8_t*)malloc(all_data_half*4);
        dest_p = (int8_t*)malloc(all_data_half);
        //dest_p = (float*)malloc(all_data_half * 4 * 4);
        all_data_half = all_data_half >> 2;
        //int k_end = (grid_w < 8) ? 1 : 2;
        int col_end = 0;
        int cell_box_len = grid_w_bytes_aligned * grid_h * grid_c / 3;

        for (row = 0; row < grid_h; row++) {
            for (ch = 0; ch < YOLO_V3_CELL_BOX_NUM; ch++) {
                x_p = src_p; // dest_p;
                y_p = x_p + grid_w_bytes_aligned * grid_h;
                width_p = y_p + grid_w_bytes_aligned * grid_h;
                height_p = width_p + grid_w_bytes_aligned * grid_h;
                score_p = height_p + grid_w_bytes_aligned * grid_h;
                class_p = score_p + grid_w_bytes_aligned * grid_h;

                col_end = grid_w;
                for (col = 0; col < col_end; col++) {
                    if (data_size == 1) {
                        box_x = (float)*x_p;
                        box_y = (float)*y_p;
                        box_w = (float)*width_p;
                        box_h = (float)*height_p;
                        box_confidence = (float)*score_p;
                    } else {
                        box_x = (float)*(uint16_t *)x_p;
                        box_y = (float)*(uint16_t *)y_p;
                        box_w = (float)*(uint16_t *)width_p;
                        box_h = (float)*(uint16_t *)height_p;
                        box_confidence = (float)*(uint16_t *)score_p;
                    }
                    box_confidence = sigmoid(do_div_scale_2(box_confidence, fScale));

                    /* Get scores of all class */
                    for (i = 0; i < class_num; i++) {
                        if (data_size == 1)
                            gp->box_class_probs[i] = (float)*(class_p + i * grid_w_bytes_aligned*grid_h);
                        else
                            gp->box_class_probs[i] = (float)*(uint16_t *)(class_p + i * grid_w_bytes_aligned*grid_h);
                    }

                    //increase pointer to next position
                    x_p += data_size;
                    y_p += data_size;
                    width_p += data_size;
                    height_p += data_size;
                    score_p += data_size;
                    class_p += data_size;

                    /* Find all classes with score higher than thresh */
                    int done_box = 0;

                    for (i = 0; i < class_num; i++) {
                        max_score_class = -1;

                        max_score = sigmoid(do_div_scale_2(gp->box_class_probs[i], fScale)) * box_confidence;
                        if (max_score >= prob_thresh_yolov3) {
                            max_score_class = i;
                        }
                        if (max_score_class != -1) {
                            if (!done_box) {
                                done_box = 1;
                                box_x = do_div_scale_2(box_x, fScale);
                                box_y = do_div_scale_2(box_y, fScale);
                                box_w = do_div_scale_2(box_w, fScale);
                                box_h = do_div_scale_2(box_h, fScale);

                                box_x = (sigmoid(box_x) + col) / grid_w;
                                box_y = (sigmoid(box_y) + row) / grid_h;
                                box_w = expf(box_w) * anchers_v[ch][0] / DIM_INPUT_COL(image_p);
                                box_h = expf(box_h) * anchers_v[ch][1] / DIM_INPUT_ROW(image_p);

                                if (src_img_mode & (uint32_t)IMAGE_FORMAT_CHANGE_ASPECT_RATIO) {
                                    bbox->x1 = (box_x - (box_w / 2)) * RAW_INPUT_COL(image_p);
                                    bbox->y1 = (box_y - (box_h / 2)) * RAW_INPUT_ROW(image_p);
                                    bbox->x2 = (box_x + (box_w / 2)) * RAW_INPUT_COL(image_p);
                                    bbox->y2 = (box_y + (box_h / 2)) * RAW_INPUT_ROW(image_p);
                                } else {
                                    bbox->x1 = (box_x - (box_w / 2)) * maxlen;
                                    bbox->y1 = (box_y - (box_h / 2)) * maxlen;
                                    bbox->x2 = (box_x + (box_w / 2)) * maxlen;
                                    bbox->y2 = (box_y + (box_h / 2)) * maxlen;
                                }
                            } else {
                                memcpy(bbox, bbox-1, sizeof(struct bounding_box_s));
                            }
                            bbox->score = max_score;
                            bbox->class_num = max_score_class;

                            bbox++;
                            good_box_count++;
                        }
                    }
                }

                //src_p += 4 * all_data;
                 src_p += cell_box_len; // grid_w_bytes_aligned;// -len; // (len - grid_w_len);
            }
            src_p = (int8_t*)OUT_NODE_ADDR(out_p) +  (row+1) * grid_w_bytes_aligned;
        }

        free(dest_p);
    }

    good_result_count = 0;

    for (i = 0; i < class_num; i++) {
        bbox = gp->bboxes_v3;
        class_good_box_count = 0;
        r_tmp_p = result_tmp_p;

        for (j = 0; j < good_box_count; j++) {
            if (bbox->class_num == i) {
                memcpy(r_tmp_p, bbox, sizeof(struct bounding_box_s));
                r_tmp_p++;
                class_good_box_count++;
            }
            bbox++;
        }

        if (class_good_box_count == 1) {
            memcpy(&result_box_p[good_result_count], &result_tmp_p[0], sizeof(struct bounding_box_s));
            good_result_count++;
        } else if (class_good_box_count >= 2) {
            qsort(result_tmp_p, class_good_box_count, sizeof(struct bounding_box_s), box_score_comparator);
            for (j = 0; j < class_good_box_count; j++) {
                if (result_tmp_p[j].score == 0)
                    continue;
                for (k = j + 1; k < class_good_box_count; k++) {
                    if (box_iou(&result_tmp_p[j], &result_tmp_p[k], IOU_UNION) > nms_thresh_yolov3) {
                        result_tmp_p[k].score = 0;
                    }
                }
            }

            int good_count = 0;
            for (j = 0; j < class_good_box_count; j++) {
                if (result_tmp_p[j].score > 0) {
                    memcpy(&result_box_p[good_result_count], &result_tmp_p[j], sizeof(struct bounding_box_s));
                    good_result_count++;
                    good_count++;
                }
                if (YOLO_MAX_DETECTION_PER_CLASS == good_count) {
                    break;
                }
            }
        }
    }

#if 1
    for (i = 0; i < good_result_count; i++) {
        result->boxes[i].x1 = (int)(result->boxes[i].x1 + (float)0.5) < 0 ? 0 : (int)(result->boxes[i].x1 + (float)0.5);
        result->boxes[i].y1 = (int)(result->boxes[i].y1 + (float)0.5) < 0 ? 0 : (int)(result->boxes[i].y1 + (float)0.5);
        result->boxes[i].x2 = (int)(result->boxes[i].x2 + (float)0.5) > RAW_INPUT_COL(image_p) ? RAW_INPUT_COL(image_p) : (int)(result->boxes[i].x2 + (float)0.5);
        result->boxes[i].y2 = (int)(result->boxes[i].y2 + (float)0.5) > RAW_INPUT_ROW(image_p) ? RAW_INPUT_ROW(image_p) : (int)(result->boxes[i].y2 + (float)0.5);
    }

#else
    // convert all bbox's coordinates to raw image
    if (good_result_count)
    bb_scale( &(result->boxes[0]), good_result_count, DIM_INPUT_COL(image_p), DIM_INPUT_ROW(image_p), RAW_INPUT_COL(image_p), RAW_INPUT_ROW(image_p), RAW_FORMAT(image_p) & (uint32_t)IMAGE_FORMAT_CHANGE_ASPECT_RATIO);
#endif

    // generate inference result outputs
    len = good_result_count * sizeof(struct bounding_box_s);
    if (image_p->post_flag & REDIRECT_OUTPUT) {
        // place outputs into buffer
        int *buf_pt = image_p->post_buf_addr;
        *buf_pt++ = result->class_count;
        *buf_pt++ = good_result_count;
        float *buf_f = (float *)buf_pt;
        for (i = 0; i < good_result_count; i++) {
            *buf_f++ = result->boxes[i].x1;
            *buf_f++ = result->boxes[i].y1;
            *buf_f++ = result->boxes[i].x2;
            *buf_f++ = result->boxes[i].y2;
            *buf_f++ = result->boxes[i].score;
            buf_pt = (int *)buf_f++;
            *buf_pt = result->boxes[i].class_num;
        }
    } else {
        printf("class_count = %d, good_result_count: %d\n", result->class_count, good_result_count);
        result->box_count = good_result_count;
        for (i = 0; i < good_result_count; i++) {
            printf("post_yolo3[%d] (%d, %d, %d, %d) %f %d\n", i, (int)result->boxes[i].x1, (int)result->boxes[i].y1, (int)result->boxes[i].x2, (int)result->boxes[i].y2, result->boxes[i].score, result->boxes[i].class_num);
        }
    }
    return len;
}

/**************************** yolo v3 for customer models **************************************/

const float anchers_htw_608_v0[3][2] = {{172,183}, {203,416}, {444,453}};
const float anchers_htw_608_v1[3][2] = {{83,103}, {47,188}, {91,312}};
const float anchers_htw_608_v2[3][2] = {{7,14}, {19,13}, {36,74}};
const float anchers_htw_416_v0[3][2] = {{117,125}, {138,284}, {303,309}};
const float anchers_htw_416_v1[3][2] = {{56,70}, {32,128}, {62,213}};
const float anchers_htw_416_v2[3][2] = {{4,9}, {13,24}, {24,50}};

int post_yolo_custom(int model_id, struct kdp_image_s *image_p)
{
    struct yolo_v3_post_globals_s *gp = &u_globals.yolov3;
    int i, j, k, div, ch, row, col, max_score_class, good_box_count, class_good_box_count, good_result_count, len, len_div_4;
    float box_x, box_y, box_w, box_h, box_confidence, max_score;
    int8_t *src_p, *x_p, *y_p, *width_p, *height_p, *score_p, *class_p, *dest_p;
    struct bounding_box_s *bbox;
    struct yolo_result_s *result;
    struct bounding_box_s *result_box_p, *result_tmp_p, *r_tmp_p;

    if ((model_id != CUSTOMER_MODEL_1) && (model_id != CUSTOMER_MODEL_2)) {
        printf("\nIncorrect model ID\n");
        return -1;
    }
    //printf("\nModel ID = %x\n", model_id);

    int data_size, grid_w, grid_h, grid_c, class_num, grid_w_bytes_aligned;
    uint32_t src_img_mode;

    float maxlen = RAW_INPUT_COL(image_p) > RAW_INPUT_ROW(image_p) ? (float)RAW_INPUT_COL(image_p) : (float)RAW_INPUT_ROW(image_p);

    src_img_mode = RAW_FORMAT(image_p);
    data_size = (POSTPROC_OUTPUT_FORMAT(image_p) & BIT(0)) + 1;     /* 1 or 2 in bytes */

    result = (struct yolo_result_s *)(POSTPROC_RESULT_MEM_ADDR(image_p));
    result_box_p = result->boxes;

    result_tmp_p = gp->result_tmp_s;

    class_num = POSTPROC_OUT_NODE_CH(image_p, 0) / YOLO_V3_CELL_BOX_NUM - YOLO_BOX_FIX_CH;

    result->class_count = class_num;

    bbox = gp->bboxes_v3;
    good_box_count = 0;

    float anchers_v[3][2];
    int idx;
    int offset = sizeof(struct out_node_s);
    struct out_node_s out_p;

    for (idx = 0; idx < POSTPROC_OUTPUT_NUM(image_p); idx++) {
        out_p = (struct out_node_s)(POSTPROC_OUT_NODE(image_p, idx));

        src_p = (int8_t *)POSTPROC_OUT_NODE_ADDR(image_p, idx);

        grid_w = OUT_NODE_COL(out_p);
        grid_h = OUT_NODE_ROW(out_p);
        grid_c = OUT_NODE_CH(out_p);
        len = grid_w * data_size;
        grid_w_bytes_aligned = round_up(len);
        //len = grid_w_bytes_aligned;
        //len_div_4 = len >> 2;
        uint32_t all_data = grid_w_bytes_aligned * (grid_c / 3);
        //dest_p = (int8_t*)malloc(all_data);
        //all_data = all_data >> 2;

        div = OUT_NODE_RADIX(out_p);  // div is unsigned int radix is actually signed
        float div2;
        if (div < 0) {  // div is minus
            div = div * (-1);
            div = pow(2, div);
            div2 = 1 / ((float) div);
        }
        else
	    div2 = (float)OUT_NODE_RADIX(out_p);
        float fScale = OUT_NODE_SCALE(out_p);
        fScale = 1 / (div2 * fScale);

        //For tiny yolo v3 custom models
        if (0 == idx) {
            if (model_id == CUSTOMER_MODEL_1)
                memcpy(anchers_v, anchers_htw_608_v0, 6*sizeof(float));
            else
                memcpy(anchers_v, anchers_htw_416_v0, 6*sizeof(float));
        } else if (1 == idx) {
            if (model_id == CUSTOMER_MODEL_1)
                memcpy(anchers_v, anchers_htw_608_v1, 6*sizeof(float));
            else
                memcpy(anchers_v, anchers_htw_416_v1, 6*sizeof(float));
        }
        else {
            if (model_id == CUSTOMER_MODEL_1)
                memcpy(anchers_v, anchers_htw_608_v2, 6*sizeof(float));
            else
                memcpy(anchers_v, anchers_htw_416_v2, 6*sizeof(float));
        }

        // Divide the data into half as not enough memory for postprocessing of tiny-yolo-v3-608
        uint32_t all_data_half = all_data >> 1;
        //dest_p = (int8_t*)malloc(all_data_half*4);
        dest_p = (int8_t*)malloc(all_data_half);
        //dest_p = (float*)malloc(all_data_half * 4 * 4);
        all_data_half = all_data_half >> 2;
        //int k_end = (grid_w < 8) ? 1 : 2;
        int col_end = 0;
        int cell_box_len = grid_w_bytes_aligned * grid_h * grid_c / 3;

        for (row = 0; row < grid_h; row++) {
            for (ch = 0; ch < YOLO_V3_CELL_BOX_NUM; ch++) {
                x_p = src_p; // dest_p;
                y_p = x_p + grid_w_bytes_aligned * grid_h;
                width_p = y_p + grid_w_bytes_aligned * grid_h;
                height_p = width_p + grid_w_bytes_aligned * grid_h;
                score_p = height_p + grid_w_bytes_aligned * grid_h;
                class_p = score_p + grid_w_bytes_aligned * grid_h;

                col_end = grid_w;
                for (col = 0; col < col_end; col++) {
                    if (data_size == 1) {
                        box_x = (float)*x_p;
                        box_y = (float)*y_p;
                        box_w = (float)*width_p;
                        box_h = (float)*height_p;
                        box_confidence = (float)*score_p;
                    } else {
                        box_x = (float)*(uint16_t *)x_p;
                        box_y = (float)*(uint16_t *)y_p;
                        box_w = (float)*(uint16_t *)width_p;
                        box_h = (float)*(uint16_t *)height_p;
                        box_confidence = (float)*(uint16_t *)score_p;
                    }
                    box_confidence = sigmoid(do_div_scale_2(box_confidence, fScale));

                    /* Get scores of all class */
                    for (i = 0; i < class_num; i++) {
                        if (data_size == 1)
                            gp->box_class_probs[i] = (float)*(class_p + i * grid_w_bytes_aligned*grid_h);
                        else
                            gp->box_class_probs[i] = (float)*(uint16_t *)(class_p + i * grid_w_bytes_aligned*grid_h);
                    }


                    //increase pointer to next position
                    x_p += data_size;
                    y_p += data_size;
                    width_p += data_size;
                    height_p += data_size;
                    score_p += data_size;
                    class_p += data_size;

                    /* Find all classes with score higher than thresh */
                    int done_box = 0;
                    for (i = 0; i < class_num; i++) {
                        max_score_class = -1;

                        max_score = sigmoid(do_div_scale_2(gp->box_class_probs[i], fScale)) * box_confidence;
                        if (max_score >= prob_thresh_yolov3) {
                            max_score_class = i;
                        }
                        if (max_score_class != -1) {
                            if (!done_box) {
                                done_box = 1;
                                box_x = do_div_scale_2(box_x, fScale);
                                box_y = do_div_scale_2(box_y, fScale);
                                box_w = do_div_scale_2(box_w, fScale);
                                box_h = do_div_scale_2(box_h, fScale);

                                box_x = (sigmoid(box_x) + col) / grid_w;
                                box_y = (sigmoid(box_y) + row) / grid_h;
                                box_w = expf(box_w) * anchers_v[ch][0] / DIM_INPUT_COL(image_p);
                                box_h = expf(box_h) * anchers_v[ch][1] / DIM_INPUT_ROW(image_p);

                                if (src_img_mode & (uint32_t)IMAGE_FORMAT_CHANGE_ASPECT_RATIO) {
                                    bbox->x1 = (box_x - (box_w / 2)) * RAW_INPUT_COL(image_p);
                                    bbox->y1 = (box_y - (box_h / 2)) * RAW_INPUT_ROW(image_p);
                                    bbox->x2 = (box_x + (box_w / 2)) * RAW_INPUT_COL(image_p);
                                    bbox->y2 = (box_y + (box_h / 2)) * RAW_INPUT_ROW(image_p);
                                } else {
                                    bbox->x1 = (box_x - (box_w / 2)) * maxlen;
                                    bbox->y1 = (box_y - (box_h / 2)) * maxlen;
                                    bbox->x2 = (box_x + (box_w / 2)) * maxlen;
                                    bbox->y2 = (box_y + (box_h / 2)) * maxlen;
                                }
                            } else {
                                memcpy(bbox, bbox-1, sizeof(struct bounding_box_s));
                            }
                            bbox->score = max_score;
                            bbox->class_num = max_score_class;
                            if (good_box_count < YOLO_GOOD_BOX_MAX)
                                bbox++;
                            else
                                break;
                            good_box_count++;
                        }
                    }
                }

                //src_p += 4 * all_data;
                 src_p += cell_box_len; // grid_w_bytes_aligned;// -len; // (len - grid_w_len);
            }
            src_p = (int8_t*)OUT_NODE_ADDR(out_p) +  (row+1) * grid_w_bytes_aligned;
        }

        free(dest_p);
    }

    good_result_count = 0;
    for (i = 0; i < class_num; i++) {
        bbox = gp->bboxes_v3;
        class_good_box_count = 0;
        r_tmp_p = result_tmp_p;

        for (j = 0; j < good_box_count; j++) {
            if (bbox->class_num == i) {
                memcpy(r_tmp_p, bbox, sizeof(struct bounding_box_s));
                r_tmp_p++;
                class_good_box_count++;
            }
            bbox++;
        }

        if (class_good_box_count == 1) {
            memcpy(&result_box_p[good_result_count], &result_tmp_p[0], sizeof(struct bounding_box_s));
            good_result_count++;
        } else if (class_good_box_count >= 2) {
            qsort(result_tmp_p, class_good_box_count, sizeof(struct bounding_box_s), box_score_comparator);
            for (j = 0; j < class_good_box_count; j++) {
                if (result_tmp_p[j].score == 0)
                    continue;
                for (k = j + 1; k < class_good_box_count; k++) {
                    if (box_iou(&result_tmp_p[j], &result_tmp_p[k], IOU_UNION) > nms_thresh_yolov3) {
                        result_tmp_p[k].score = 0;
                    }
                }
            }

            int good_count = 0;
            for (j = 0; j < class_good_box_count; j++) {
                if (result_tmp_p[j].score > 0) {
                    memcpy(&result_box_p[good_result_count], &result_tmp_p[j], sizeof(struct bounding_box_s));
                    good_result_count++;
                    good_count++;
                }
                if (YOLO_MAX_DETECTION_PER_CLASS == good_count) {
                    break;
                }
            }
        }
    }

    for (i = 0; i < good_result_count; i++) {
        result->boxes[i].x1 = (int)(result->boxes[i].x1 + (float)0.5) < 0 ? 0 : (int)(result->boxes[i].x1 + (float)0.5);
        result->boxes[i].y1 = (int)(result->boxes[i].y1 + (float)0.5) < 0 ? 0 : (int)(result->boxes[i].y1 + (float)0.5);
        result->boxes[i].x2 = (int)(result->boxes[i].x2 + (float)0.5) > RAW_INPUT_COL(image_p) ? RAW_INPUT_COL(image_p) : (int)(result->boxes[i].x2 + (float)0.5);
        result->boxes[i].y2 = (int)(result->boxes[i].y2 + (float)0.5) > RAW_INPUT_ROW(image_p) ? RAW_INPUT_ROW(image_p) : (int)(result->boxes[i].y2 + (float)0.5);
    }

    printf("good_result_count: %d\n", good_result_count);
    result->box_count = good_result_count;
//    for (i = good_result_count-1; i > -1; i--) {
    for (i = 0; i < good_result_count; i++) {
        printf("post_yolo3[%d] (%d, %d, %d, %d) %f %d\n", i, (int)result->boxes[i].x1, (int)result->boxes[i].y1, (int)result->boxes[i].x2, (int)result->boxes[i].y2, result->boxes[i].score, result->boxes[i].class_num);
    }
    len = good_result_count * sizeof(struct bounding_box_s);

    return len;
}

static int inet_comparator(const void *pa, const void *pb)
{
    float a, b;

    a = ((struct imagenet_result_s *)pa)->score;
    b = ((struct imagenet_result_s *)pb)->score;

    return float_comparator(a, b);
}

/**************************** imagenet classification **************************************/
int post_imgnet_classification(int model_id, struct kdp_image_s *image_p)
{
    struct imagenet_post_globals_s *gp = &u_globals.imgnet;
    uint8_t *result_p;
    int i, len, data_size, div;
    float scale;

    data_size = (POSTPROC_OUTPUT_FORMAT(image_p) & BIT(0)) + 1;     /* 1 or 2 in bytes */

    int8_t *src_p = (int8_t *)POSTPROC_OUT_NODE_ADDR(image_p, 0);
    int grid_w = POSTPROC_OUT_NODE_COL(image_p, 0);
    len = grid_w * data_size;
    int grid_w_bytes_aligned = round_up(len);
    int w_bytes_to_skip = grid_w_bytes_aligned - len;
    len = grid_w_bytes_aligned;

    int ch = POSTPROC_OUT_NODE_CH(image_p, 0);

    /* Convert to float */
    scale = POSTPROC_OUT_NODE_SCALE(image_p, 0);//*(float *)&
    div = 1 << POSTPROC_OUT_NODE_RADIX(image_p, 0);
    for (i = 0; i < ch; i++) {
        gp->temp[i].index = i;
        gp->temp[i].score = (float)*src_p;
        gp->temp[i].score = do_div_scale(gp->temp[i].score, div, scale);
        src_p += data_size + w_bytes_to_skip;
    }

    softmax(gp->temp, ch);
    qsort(gp->temp, ch, sizeof(struct imagenet_result_s), inet_comparator);

    result_p = (uint8_t *)(POSTPROC_RESULT_MEM_ADDR(image_p));
    len = sizeof(struct imagenet_result_s) * IMAGENET_TOP_MAX;
    memcpy(result_p, gp->temp, len);
    return len;
}

/**************************** yolo v5 **************************************/
#define HelperMax(a,b) (((a)>(b))?(a):(b))
#define HelperMin(a,b) (((a)<(b))?(a):(b))
void MaxMin(float lhs, float rhs, float *min, float *max) {
    if (lhs >= rhs) {
        *min = rhs;
        *max = lhs;
    } else {
        *min = lhs;
        *max = rhs;
    }
}

typedef struct node {
    int data;
    float score;
    struct node* next;
} Node_dsp;

// Function to Create A New Node
Node_dsp* newNode(int d, float s)
{
    Node_dsp* temp = (Node_dsp *)malloc(sizeof(Node_dsp));
    temp->data = d;
    temp->score = s;
    temp->next = NULL;
    return temp;
}

// Return the value at head
int peek(Node_dsp** head)
{
    return (*head)->data;
}
// Return the value at head
Node_dsp* peek_node(Node_dsp** head)
{
    return (*head);
}
// Removes the element with the
// highest priority form the list
void pop(Node_dsp** head)
{
    Node_dsp* temp = *head;
    if(temp) {
    (*head) = (*head)->next;
    free(temp);
    }
}

// Function to push according to priority
void push(Node_dsp** head, int d, float s)
{
	if(*head == NULL) {
		*head = newNode(d, s);
		return;
	}
    Node_dsp* start = (*head);
    // Create new Node
    Node_dsp* temp = newNode(d, s);
    if ((*head)->score < s) {
        // Insert New Node before head
        temp->next = *head;
        (*head) = temp;
    } else {
        // Traverse the list and find a
        // position to insert new node
        while (start->next != NULL && start->next->score > s) {
            start = start->next;
        }
        // Either at the ends of the list
        // or at required position
        temp->next = start->next;
        start->next = temp;
    }
}
void flush(Node_dsp** head)
{
	Node_dsp* start = (*head);
	while(start) {
		Node_dsp* temp = start;
		start = start->next;
		free(temp);
	}
	*head = NULL;
}
// Function to check is list is empty
int isEmpty(Node_dsp** head)
{
    return (*head) == NULL;
}

bool SuppressByIoU_Q15(const int32_t *boxes_data, int box_idx1, int box_idx2, int center_point_box, float iou_threshold)
{
	  float x1_min;
	  float y1_min;
	  float x1_max;
	  float y1_max;
	  float x2_min;
	  float y2_min;
	  float x2_max;
	  float y2_max;

	  const int32_t* _box1 = boxes_data + 4 * box_idx1;
	  const int32_t* _box2 = boxes_data + 4 * box_idx2;

	  float box1[4], box2[4];
	  box1[0] = _box1[0] >> 15;
	  box1[1] = _box1[1] >> 15;
	  box1[2] = _box1[2] >> 15;
	  box1[3] = _box1[3] >> 15;
	  box2[0] = _box2[0] >> 15;
	  box2[1] = _box2[1] >> 15;
	  box2[2] = _box2[2] >> 15;
	  box2[3] = _box2[3] >> 15;

	  //printf("box1(%d-th box) : %f %f %f %f\n", box_idx1, box1[0], box1[1], box1[2], box1[3]);
	  //printf("box2(%d-th box) : %f %f %f %f\n", box_idx2, box2[0], box2[1], box2[2], box2[3]);
	  // center_point_box_ only support 0 or 1
	  if (0 == center_point_box) {
	      // boxes data format [y1, x1, y2, x2],
	      MaxMin(box1[1], box1[3], &x1_min, &x1_max);
	      MaxMin(box1[0], box1[2], &y1_min, &y1_max);
	      MaxMin(box2[1], box2[3], &x2_min, &x2_max);
	      MaxMin(box2[0], box2[2], &y2_min, &y2_max);
	  } else {
	      // 1 == center_point_box_ => boxes data format [x_center, y_center, width, height]
	      float box1_width_half = box1[2] / 2;
	      float box1_height_half = box1[3] / 2;
	      float box2_width_half = box2[2] / 2;
	      float box2_height_half = box2[3] / 2;

	      x1_min = box1[0] - box1_width_half;
	      x1_max = box1[0] + box1_width_half;
	      y1_min = box1[1] - box1_height_half;
	      y1_max = box1[1] + box1_height_half;

	      x2_min = box2[0] - box2_width_half;
	      x2_max = box2[0] + box2_width_half;
	      y2_min = box2[1] - box2_height_half;
	      y2_max = box2[1] + box2_height_half;
	  }

	  const float intersection_x_min = HelperMax(x1_min, x2_min);
	  const float intersection_y_min = HelperMax(y1_min, y2_min);
	  const float intersection_x_max = HelperMin(x1_max, x2_max);
	  const float intersection_y_max = HelperMin(y1_max, y2_max);

	  const float intersection_area = HelperMax(intersection_x_max - intersection_x_min, .0f) *
	                                  HelperMax(intersection_y_max - intersection_y_min, .0f);

	  if (intersection_area <= .0f) {
	      return false;
	  }

	  const float area1 = (x1_max - x1_min) * (y1_max - y1_min);
	  const float area2 = (x2_max - x2_min) * (y2_max - y2_min);
	  const float union_area = area1 + area2 - intersection_area;

	  if (area1 <= .0f || area2 <= .0f || union_area <= .0f) {
	      return false;
	  }

	  const float intersection_over_union = intersection_area / union_area;

	  return intersection_over_union > iou_threshold;
}

#define YOLO_V5_MODEL_INPUT_WIDTH	640
#define YOLO_V5_MODEL_INPUT_HEIGHT	640
#define YOLO_V5_GRID0_W       		(YOLO_V5_MODEL_INPUT_WIDTH / 8)
#define YOLO_V5_GRID0_H       		(YOLO_V5_MODEL_INPUT_HEIGHT / 8)
#define YOLO_V5_GRID1_W       		(YOLO_V5_MODEL_INPUT_WIDTH / 16)
#define YOLO_V5_GRID1_H       		(YOLO_V5_MODEL_INPUT_HEIGHT / 16)
#define YOLO_V5_GRID2_W       		(YOLO_V5_MODEL_INPUT_WIDTH / 32)
#define YOLO_V5_GRID2_H       		(YOLO_V5_MODEL_INPUT_HEIGHT / 32)
#define YOLO_V5_CELL_BOX_NUM    	3

#define YOLO_V5_MAX_GRID_W      	YOLO_V5_GRID0_W
#define YOLO_V5_MAX_GRID_H      	YOLO_V5_GRID0_H
#define YOLO_V5_MIN_GRID_W      	YOLO_V5_GRID2_W
#define YOLO_V5_MIN_GRID_H      	YOLO_V5_GRID2_H
#define YOLO_V5_MAX_GRID_CH		255 // YOLO_V5_CELL_BOX_NUM * (YOLO_CLASS_MAX + 5)
#define YOLO_V5_MAX_BBOXES		YOLO_V5_CELL_BOX_NUM * (YOLO_V5_GRID0_W * YOLO_V5_GRID0_H + YOLO_V5_GRID1_W * YOLO_V5_GRID1_H + YOLO_V5_GRID2_W * YOLO_V5_GRID2_H)

// yolov5s input
float iou_threshold = 0.5;
float score_threshold = 0.15; // 0.4;
int anchors[3][6] = {{10, 13, 16, 30, 33, 23}, {30, 61, 62, 45, 59, 119}, {116, 90, 156, 198, 373, 326}};
int strides[3] = {8, 16, 32};
// yolov5s output
typedef struct yolov5s_bboxes {
	int bboxes_count;
	union {
		float bboxes[YOLO_V5_MAX_BBOXES * 4];
		int32_t sbboxes[YOLO_V5_MAX_BBOXES * 4];
	};
	union {
		float scores[YOLO_CLASS_MAX][YOLO_V5_MAX_BBOXES];
		int32_t sscores[YOLO_CLASS_MAX][YOLO_V5_MAX_BBOXES];
	};
} yolov5s_bboxes;
yolov5s_bboxes bboxes_candidates;  // allocate bboxes storage
#if 1
void bboxes_scale( struct bounding_box_s *bboxes, int size, int model_w, int model_h, int raw_w, int raw_h, bool keep_ratio )
{
	float ratio_w = (float)model_w / raw_w;
	float ratio_h = (float)model_h / raw_h;
	if(!keep_ratio) {
		ratio_h = ratio_w = (ratio_w < ratio_h) ? ratio_w : ratio_h;
	}
	//float ratio = MIN((float)DIM_INPUT_COL(image_p)/RAW_INPUT_COL(image_p) , DIM_INPUT_ROW(image_p)/RAW_INPUT_ROW(image_p));
	for(int i = 0; i < size; i++) {
		bboxes[i].x2 = (bboxes[i].x2 - bboxes[i].x1) / ratio_w; // w
		bboxes[i].y2 = (bboxes[i].y2 - bboxes[i].y1) / ratio_h; // h
		bboxes[i].x1 /= ratio_w;
		bboxes[i].y1 /= ratio_h;
		bboxes[i].x2 += bboxes[i].x1;
		bboxes[i].y2 += bboxes[i].y1;
		// limit Rectangle
		bboxes[i].x1 = (bboxes[i].x1 > 0) ? bboxes[i].x1 : 0;
		bboxes[i].y1 = (bboxes[i].y1 > 0) ? bboxes[i].y1 : 0;
		bboxes[i].x2 = (bboxes[i].x2 < raw_w) ? bboxes[i].x2 : raw_w;
		bboxes[i].y2 = (bboxes[i].y2 < raw_h) ? bboxes[i].y2 : raw_h;
	}
}
#endif
#define round(x) ((x + 15) / 16) * 16

#define INT16_QNUM				(7)
#define INT16_DIVIDOR			(1 << INT16_QNUM)

#define INT16_SIGMOID_MIN		(-5 * INT16_DIVIDOR)
#define INT16_SIGMOID_MAX		( 5 * INT16_DIVIDOR)
#define INT16_SIGMOID_TOTAL  	(INT16_SIGMOID_MAX - INT16_SIGMOID_MIN + 1)

int16_t __attribute__((aligned(64))) sigmoid_tbl[INT16_SIGMOID_TOTAL] = {
		219, 221, 222, 224, 226, 227, 229, 231, 233, 235, 237, 238, 240, 242, 244, 246,
		248, 250, 252, 254, 256, 258, 260, 262, 264, 266, 268, 270, 272, 274, 276, 278,
		281, 283, 285, 287, 289, 292, 294, 296, 299, 301, 303, 306, 308, 310, 313, 315,
		318, 320, 323, 325, 328, 330, 333, 335, 338, 341, 343, 346, 349, 351, 354, 357,
		360, 362, 365, 368, 371, 374, 377, 380, 382, 385, 388, 391, 394, 398, 401, 404,
		407, 410, 413, 416, 420, 423, 426, 429, 433, 436, 440, 443, 446, 450, 453, 457,
		460, 464, 467, 471, 475, 478, 482, 486, 490, 493, 497, 501, 505, 509, 513, 517,
		521, 525, 529, 533, 537, 541, 545, 550, 554, 558, 562, 567, 571, 575, 580, 584,
		589, 593, 598, 603, 607, 612, 617, 621, 626, 631, 636, 641, 646, 651, 656, 661,
		666, 671, 676, 681, 686, 692, 697, 702, 708, 713, 719, 724, 730, 735, 741, 747,
		752, 758, 764, 770, 776, 782, 788, 794, 800, 806, 812, 818, 825, 831, 837, 844,
		850, 857, 863, 870, 876, 883, 890, 897, 903, 910, 917, 924, 931, 938, 946, 953,
		960, 967, 975, 982, 990, 997, 1005, 1012, 1020, 1028, 1036, 1043, 1051, 1059, 1067, 1076,
		1084, 1092, 1100, 1109, 1117, 1125, 1134, 1142, 1151, 1160, 1169, 1177, 1186, 1195, 1204, 1213,
		1223, 1232, 1241, 1251, 1260, 1269, 1279, 1289, 1298, 1308, 1318, 1328, 1338, 1348, 1358, 1368,
		1379, 1389, 1399, 1410, 1421, 1431, 1442, 1453, 1464, 1475, 1486, 1497, 1508, 1519, 1531, 1542,
		1554, 1565, 1577, 1589, 1600, 1612, 1624, 1637, 1649, 1661, 1673, 1686, 1698, 1711, 1724, 1737,
		1749, 1762, 1775, 1789, 1802, 1815, 1829, 1842, 1856, 1870, 1883, 1897, 1911, 1925, 1940, 1954,
		1968, 1983, 1998, 2012, 2027, 2042, 2057, 2072, 2087, 2103, 2118, 2134, 2149, 2165, 2181, 2197,
		2213, 2229, 2245, 2262, 2278, 2295, 2312, 2328, 2345, 2362, 2380, 2397, 2414, 2432, 2450, 2467,
		2485, 2503, 2521, 2540, 2558, 2576, 2595, 2614, 2633, 2652, 2671, 2690, 2709, 2729, 2748, 2768,
		2788, 2808, 2828, 2848, 2869, 2889, 2910, 2931, 2952, 2973, 2994, 3015, 3037, 3058, 3080, 3102,
		3124, 3146, 3168, 3191, 3213, 3236, 3259, 3282, 3305, 3328, 3352, 3375, 3399, 3423, 3447, 3471,
		3496, 3520, 3545, 3569, 3594, 3619, 3645, 3670, 3696, 3721, 3747, 3773, 3799, 3826, 3852, 3879,
		3906, 3932, 3960, 3987, 4014, 4042, 4070, 4098, 4126, 4154, 4182, 4211, 4240, 4269, 4298, 4327,
		4356, 4386, 4416, 4446, 4476, 4506, 4537, 4567, 4598, 4629, 4660, 4691, 4723, 4755, 4786, 4819,
		4851, 4883, 4916, 4948, 4981, 5014, 5048, 5081, 5115, 5149, 5183, 5217, 5251, 5286, 5320, 5355,
		5390, 5426, 5461, 5497, 5533, 5569, 5605, 5641, 5678, 5715, 5752, 5789, 5826, 5864, 5901, 5939,
		5977, 6015, 6054, 6093, 6131, 6171, 6210, 6249, 6289, 6329, 6369, 6409, 6449, 6490, 6530, 6571,
		6613, 6654, 6695, 6737, 6779, 6821, 6863, 6906, 6949, 6991, 7035, 7078, 7121, 7165, 7209, 7253,
		7297, 7341, 7386, 7431, 7476, 7521, 7566, 7612, 7658, 7704, 7750, 7796, 7842, 7889, 7936, 7983,
		8030, 8078, 8126, 8173, 8221, 8270, 8318, 8367, 8415, 8464, 8513, 8563, 8612, 8662, 8712, 8762,
		8812, 8863, 8913, 8964, 9015, 9066, 9117, 9169, 9221, 9272, 9324, 9377, 9429, 9482, 9534, 9587,
		9640, 9694, 9747, 9801, 9854, 9908, 9962, 10017, 10071, 10126, 10180, 10235, 10290, 10346, 10401, 10456,
		10512, 10568, 10624, 10680, 10737, 10793, 10850, 10906, 10963, 11020, 11078, 11135, 11192, 11250, 11308, 11366,
		11424, 11482, 11540, 11599, 11658, 11716, 11775, 11834, 11893, 11953, 12012, 12071, 12131, 12191, 12251, 12311,
		12371, 12431, 12491, 12552, 12612, 12673, 12734, 12795, 12856, 12917, 12978, 13039, 13101, 13162, 13224, 13285,
		13347, 13409, 13471, 13533, 13595, 13657, 13719, 13782, 13844, 13907, 13969, 14032, 14095, 14157, 14220, 14283,
		14346, 14409, 14472, 14535, 14599, 14662, 14725, 14789, 14852, 14915, 14979, 15043, 15106, 15170, 15233, 15297,
		15361, 15425, 15488, 15552, 15616, 15680, 15744, 15808, 15872, 15936, 16000, 16064, 16128, 16192, 16256, 16320,
		16384, 16448, 16511, 16575, 16639, 16703, 16767, 16831, 16895, 16959, 17023, 17087, 17151, 17215, 17279, 17342,
		17406, 17470, 17534, 17597, 17661, 17724, 17788, 17852, 17915, 17978, 18042, 18105, 18168, 18232, 18295, 18358,
		18421, 18484, 18547, 18610, 18672, 18735, 18798, 18860, 18923, 18985, 19048, 19110, 19172, 19234, 19296, 19358,
		19420, 19482, 19543, 19605, 19666, 19728, 19789, 19850, 19911, 19972, 20033, 20094, 20155, 20215, 20276, 20336,
		20396, 20456, 20516, 20576, 20636, 20696, 20755, 20814, 20874, 20933, 20992, 21051, 21109, 21168, 21227, 21285,
		21343, 21401, 21459, 21517, 21575, 21632, 21689, 21747, 21804, 21861, 21917, 21974, 22030, 22087, 22143, 22199,
		22255, 22311, 22366, 22421, 22477, 22532, 22587, 22641, 22696, 22750, 22805, 22859, 22913, 22966, 23020, 23073,
		23127, 23180, 23233, 23285, 23338, 23390, 23443, 23495, 23546, 23598, 23650, 23701, 23752, 23803, 23854, 23904,
		23955, 24005, 24055, 24105, 24155, 24204, 24254, 24303, 24352, 24400, 24449, 24497, 24546, 24594, 24641, 24689,
		24737, 24784, 24831, 24878, 24925, 24971, 25017, 25063, 25109, 25155, 25201, 25246, 25291, 25336, 25381, 25426,
		25470, 25514, 25558, 25602, 25646, 25689, 25732, 25776, 25818, 25861, 25904, 25946, 25988, 26030, 26072, 26113,
		26154, 26196, 26237, 26277, 26318, 26358, 26398, 26438, 26478, 26518, 26557, 26597, 26636, 26674, 26713, 26752,
		26790, 26828, 26866, 26903, 26941, 26978, 27015, 27052, 27089, 27126, 27162, 27198, 27234, 27270, 27306, 27341,
		27377, 27412, 27447, 27481, 27516, 27550, 27584, 27618, 27652, 27686, 27719, 27753, 27786, 27819, 27851, 27884,
		27916, 27948, 27981, 28012, 28044, 28076, 28107, 28138, 28169, 28200, 28230, 28261, 28291, 28321, 28351, 28381,
		28411, 28440, 28469, 28498, 28527, 28556, 28585, 28613, 28641, 28669, 28697, 28725, 28753, 28780, 28807, 28835,
		28861, 28888, 28915, 28941, 28968, 28994, 29020, 29046, 29071, 29097, 29122, 29148, 29173, 29198, 29222, 29247,
		29271, 29296, 29320, 29344, 29368, 29392, 29415, 29439, 29462, 29485, 29508, 29531, 29554, 29576, 29599, 29621,
		29643, 29665, 29687, 29709, 29730, 29752, 29773, 29794, 29815, 29836, 29857, 29878, 29898, 29919, 29939, 29959,
		29979, 29999, 30019, 30038, 30058, 30077, 30096, 30115, 30134, 30153, 30172, 30191, 30209, 30227, 30246, 30264,
		30282, 30300, 30317, 30335, 30353, 30370, 30387, 30405, 30422, 30439, 30455, 30472, 30489, 30505, 30522, 30538,
		30554, 30570, 30586, 30602, 30618, 30633, 30649, 30664, 30680, 30695, 30710, 30725, 30740, 30755, 30769, 30784,
		30799, 30813, 30827, 30842, 30856, 30870, 30884, 30897, 30911, 30925, 30938, 30952, 30965, 30978, 30992, 31005,
		31018, 31030, 31043, 31056, 31069, 31081, 31094, 31106, 31118, 31130, 31143, 31155, 31167, 31178, 31190, 31202,
		31213, 31225, 31236, 31248, 31259, 31270, 31281, 31292, 31303, 31314, 31325, 31336, 31346, 31357, 31368, 31378,
		31388, 31399, 31409, 31419, 31429, 31439, 31449, 31459, 31469, 31478, 31488, 31498, 31507, 31516, 31526, 31535,
		31544, 31554, 31563, 31572, 31581, 31590, 31598, 31607, 31616, 31625, 31633, 31642, 31650, 31658, 31667, 31675,
		31683, 31691, 31700, 31708, 31716, 31724, 31731, 31739, 31747, 31755, 31762, 31770, 31777, 31785, 31792, 31800,
		31807, 31814, 31821, 31829, 31836, 31843, 31850, 31857, 31864, 31870, 31877, 31884, 31891, 31897, 31904, 31910,
		31917, 31923, 31930, 31936, 31942, 31949, 31955, 31961, 31967, 31973, 31979, 31985, 31991, 31997, 32003, 32009,
		32015, 32020, 32026, 32032, 32037, 32043, 32048, 32054, 32059, 32065, 32070, 32075, 32081, 32086, 32091, 32096,
		32101, 32106, 32111, 32116, 32121, 32126, 32131, 32136, 32141, 32146, 32150, 32155, 32160, 32164, 32169, 32174,
		32178, 32183, 32187, 32192, 32196, 32200, 32205, 32209, 32213, 32217, 32222, 32226, 32230, 32234, 32238, 32242,
		32246, 32250, 32254, 32258, 32262, 32266, 32270, 32274, 32277, 32281, 32285, 32289, 32292, 32296, 32300, 32303,
		32307, 32310, 32314, 32317, 32321, 32324, 32327, 32331, 32334, 32338, 32341, 32344, 32347, 32351, 32354, 32357,
		32360, 32363, 32366, 32369, 32373, 32376, 32379, 32382, 32385, 32387, 32390, 32393, 32396, 32399, 32402, 32405,
		32407, 32410, 32413, 32416, 32418, 32421, 32424, 32426, 32429, 32432, 32434, 32437, 32439, 32442, 32444, 32447,
		32449, 32452, 32454, 32457, 32459, 32461, 32464, 32466, 32468, 32471, 32473, 32475, 32478, 32480, 32482, 32484,
		32486, 32489, 32491, 32493, 32495, 32497, 32499, 32501, 32503, 32505, 32507, 32509, 32511, 32513, 32515, 32517,
		32519, 32521, 32523, 32525, 32527, 32529, 32530, 32532, 32534, 32536, 32538, 32540, 32541, 32543, 32545, 32546,
		32548
};
int16_t int16_sigmoid_tbl(int16_t x) {
	if(x < INT16_SIGMOID_MIN)
		x = INT16_SIGMOID_MIN;
	if(x > INT16_SIGMOID_MAX)
		x = INT16_SIGMOID_MAX;
	return sigmoid_tbl[x - INT16_SIGMOID_MIN];
}

uint8_t __attribute__((aligned(64))) pBankBuffPool0[32*1024];
uint8_t __attribute__((aligned(64))) pBankBuffPool1[240*1024];

int32_t *updated_anchor = (int32_t *)&pBankBuffPool1[0*1024];
int16_t *boxes = (int16_t *)&pBankBuffPool1[120*1024];
int16_t *probability = (int16_t *)&pBankBuffPool1[180*1024];
int16_t *classification = (int16_t *)&pBankBuffPool1[195*1024];
int32_t *score = (int32_t *)&pBankBuffPool1[210*1024];
int32_t *bboxes_local = (int32_t *)&pBankBuffPool1[120*1024];
int post_yolo_v5(int model_id, struct kdp_image_s *image_p)
{
    float *ext_param = POSTPROC_PARAMS_P(image_p);
    if ((ext_param) && (*ext_param)) {
        score_threshold = *ext_param;
    }
    //printf("v5 threshold = %f\n", score_threshold);

    int32_t fp32_score_threshold = (int32_t)(score_threshold * powf(2, 30));
    int num_of_classes;
    //bboxes_candidates = POSTPROC_OUTPUT_MEM_ADDR4(image_p);
#if 0
    memset(&bboxes_candidates, 0, sizeof(yolov5s_bboxes));
    memset(&pBankBuffPool0, 0, 32*1024);
    memset(&pBankBuffPool1, 0, 240*1024);
#endif
    int base = 0;
    struct out_node_s out_p;

//    init_mem4(POSTPROC_OUTPUT_MEM_ADDR4(image_p), 0x800000);
    for(int layer = 0; layer < POSTPROC_OUTPUT_NUM(image_p); layer++)
    {
//		Out_Node *out_p = (Out_Node *)image_p->pParsedModel->pNodePositions[image_p->pParsedModel->current_node_id++];
        out_p = (struct out_node_s)(POSTPROC_OUT_NODE(image_p, layer));
	    int8_t *conv_out = (int8_t *)OUT_NODE_ADDR(out_p);
	    int *anchor = anchors[layer];
	    int stride = strides[layer];
	    int num_anchors = 3;
	    int data_size = (POSTPROC_OUTPUT_FORMAT(image_p) & BIT(0)) + 1;
	    int nrows = OUT_NODE_ROW(out_p);
	    int ncols = OUT_NODE_COL(out_p);
	    int nchs = OUT_NODE_CH(out_p);
	    float div = powf(2, OUT_NODE_RADIX(out_p));
	    float scale = *(float *)&(OUT_NODE_SCALE(out_p));
	    //int8_t sscale = (int8_t)((1.0 / div / scale) * powf(2, 7));
	    int16_t sscale = (int16_t)((1.0 / div / scale) * powf(2, 15));
	    num_of_classes = nchs / num_anchors - 5;

#if 0
	    printf("[layer = %d] : nrows = %d; ncols = %d; nchs = %d; data_size = %d; div = %f; sscale = %d\n", layer, nrows, ncols, nchs, data_size, div, sscale);
	    printf("%08x %08x\n", *(u32*)conv_out, *(u32*)&conv_out[4]);
#endif
	    // element-wise sigmoid operations
	    // layer 0 : 1 x 255 x 80 x 80, reshape to 1 x 3 x 85 x 80 x 80, transpose to 1 x 3 x 80 x 80 x 85
	    // layer 1 : 1 x 255 x 40 x 40, reshape to 1 x 3 x 85 x 40 x 40, transpose to 1 x 3 x 40 x 40 x 85
	    // layer 2 : 1 x 255 x 20 x 20, reshape to 1 x 3 x 85 x 20 x 20, transpose to 1 x 3 x 20 x 20 x 85
	    int stride1 = (nchs / num_anchors) * nrows * round(ncols);
	    int stride2 = nrows * round(ncols);
	    int stride3 = round(ncols);
//	    int16_t *features = (int16_t *)mem4_malloc(nchs * nrows * round(ncols) * sizeof(int16_t));
	    int feature_size = nchs * nrows * round(ncols) * sizeof(int16_t);
	    int16_t *features = (int16_t *)malloc(feature_size);
	    memset(features, 0, feature_size);
        for(int b = 0; b < num_anchors; b++) {
            for(int c = 0; c < nchs / num_anchors; c++) {
                for(int h = 0; h < nrows; h++) {
                    for(int w = 0; w < ncols; w++) {
                        features[b * stride1 + c * stride2 + h * stride3 + w] = int16_sigmoid_tbl(conv_out[b * stride1 + c * stride2 + h * stride3 + w] * sscale >> 8);
                    }
                }
            }
        }

        // scan scores
        for(int k = 0; k < num_anchors; k++) {
            // update anchor
            memcpy(boxes, &features[k * stride1 + 0 * stride2], 4 * stride2 * 2); // x, y, w, h
            for(int row = 0; row < nrows; row++) {
                for(int col = 0; col < ncols; col++) {
                    int index0 = row * stride3 + col;
                    int index1 = row * ncols + col;
                    int16_t box_x = boxes[index0 + 0 * stride2];
                    int16_t box_y = boxes[index0 + 1 * stride2];
                    int16_t box_w = boxes[index0 + 2 * stride2];
                    int16_t box_h = boxes[index0 + 3 * stride2];
                    int16_t grid_x = (int16_t)col;
                    int16_t grid_y = (int16_t)row;

                    box_w = (box_w * box_w) >> 15;
                    box_h = (box_h * box_h) >> 15;
                    int32_t _x = (box_x * 2 - (1 << 14) + (grid_x << 15)) * stride; // Q15
                    int32_t _y = (box_y * 2 - (1 << 14) + (grid_y << 15) ) * stride; // Q15
                    int32_t _w = box_w * 4 * anchor[k*2]; // Q1.15 * Q1.15 * Q16.0 = Q18.30 >> 15 -> Q15
                    int32_t _h = box_h * 4 * anchor[k*2+1]; // Q1.15 * Q1.15 * Q16.0 = Q18.30 >> 15 -> Q15
                    int32_t xleft = (_x - _w / 2);
                    int32_t yleft = (_y - _h / 2);

                    updated_anchor[4 * index1 + 0] = xleft;
                    updated_anchor[4 * index1 + 1] = yleft;
                    updated_anchor[4 * index1 + 2] = xleft + _w;
                    updated_anchor[4 * index1 + 3] = yleft + _h;
                }
            }
            memcpy(&bboxes_candidates.sbboxes[(base + k * nrows * ncols) * 4], &updated_anchor[0], 4 * nrows * ncols * sizeof(int32_t));
            memcpy(probability, &features[k * stride1 + 4 * stride2], stride2 * 2);
            for(int c = 5; c < nchs / num_anchors; c++) {
                memcpy(classification, &features[k * stride1 + c * stride2], stride2 * 2);
                int i = 0;
                for(int row = 0; row < nrows; row++) {
                    for (int col = 0; col < ncols; col++) {
                        score[i++] = probability[row * stride3 + col] * classification[row * stride3 + col];
                    }
                }
                //printf("address of sscores = %p\n", &bboxes_candidates->sscores[c-5][base + k * nrows * ncols]);
                memcpy(&bboxes_candidates.sscores[c-5][base + k * nrows * ncols], &score[0], nrows * ncols * sizeof(int32_t));
            }
        }
        free(features);
        base += (num_anchors * nrows * ncols);
    }

    bboxes_candidates.bboxes_count = base;
    struct yolo_result_s* result = (struct yolo_result_s *)(POSTPROC_RESULT_MEM_ADDR(image_p));
    result->box_count = 0;
    // nms
    int max_output_per_class = 20;
    int selected_indices_inside_class[20];

    for(int class_idx = 0; class_idx < num_of_classes; class_idx++) {
        //dbg_msg("class_idx %d ...\n", class_idx);
        memcpy(bboxes_local, &bboxes_candidates.sscores[class_idx][0], bboxes_candidates.bboxes_count * sizeof(int32_t));
        Node_dsp *sorted_scores_with_index = NULL;
        // Filter by score_threshold
        for(int box_idx = 0; box_idx < bboxes_candidates.bboxes_count; box_idx++) {
            if(bboxes_local[box_idx] > fp32_score_threshold) {
                push(&sorted_scores_with_index, box_idx, bboxes_local[box_idx]);
            }
            if(bboxes_candidates.sscores[class_idx][box_idx] > fp32_score_threshold) {
                push(&sorted_scores_with_index, box_idx, bboxes_candidates.sscores[class_idx][box_idx]);
            }
        }
        int next_top_score_idx;
        int selected_indices = 0;
        //int *selected_indices_inside_class = (int *)calloc(bboxes_candidates->bboxes_count, sizeof(int));
        // Get the next box with top score, filter by iou_threshold
        while(!isEmpty(&sorted_scores_with_index)) {
            next_top_score_idx = peek(&sorted_scores_with_index);
            pop(&sorted_scores_with_index);
            bool selected = true;
            for(int selected_idx = 0; selected_idx < selected_indices; selected_idx++) {
                if(SuppressByIoU_Q15(bboxes_candidates.sbboxes, selected_indices_inside_class[selected_idx],       next_top_score_idx, 0, iou_threshold)) {
                    selected = false;
                    break;
                 }
            }
            if(selected) {
                if(max_output_per_class > 0 && selected_indices >= max_output_per_class)
                    break;
                selected_indices_inside_class[selected_indices++] = next_top_score_idx;
            }
        } // while
        for(int i = 0; i < selected_indices; i++) {
            //printf("selected_indices_inside_class[%d] = %d\n", i, selected_indices_inside_class[i]);
            result->boxes[result->box_count].x1 = bboxes_candidates.sbboxes[4 * selected_indices_inside_class[i] + 0] >> 15;
            result->boxes[result->box_count].y1 = bboxes_candidates.sbboxes[4 * selected_indices_inside_class[i] + 1] >> 15;
            result->boxes[result->box_count].x2 = bboxes_candidates.sbboxes[4 * selected_indices_inside_class[i] + 2] >> 15;
            result->boxes[result->box_count].y2 = bboxes_candidates.sbboxes[4 * selected_indices_inside_class[i] + 3] >> 15;
            result->boxes[result->box_count].class_num = class_idx;
            result->boxes[result->box_count].score = (float)bboxes_candidates.sscores[class_idx][selected_indices_inside_class[i]] / powf(2, 30);
#if 0
            printf("post_yolov5s [%d %d %d %d] score - %f, class - %d\n", (int)result->boxes[result->box_count].x1, (int)result->boxes[result->box_count].y1, (int) result->boxes[result->box_count].x2, (int)result->boxes[result->box_count].y2, result->boxes[result->box_count].score, result->boxes[result->box_count].class_num);
#endif
            result->box_count++;
        }
        flush(&sorted_scores_with_index);
        //free(selected_indices_inside_class);
    } // for class_idx
#if 1
    // convert all bbox's coordinates to raw image
    bboxes_scale( &(result->boxes[0]), result->box_count, DIM_INPUT_COL(image_p), DIM_INPUT_ROW(image_p), RAW_INPUT_COL(image_p), RAW_INPUT_ROW(image_p), RAW_FORMAT(image_p) & (uint32_t)IMAGE_FORMAT_CHANGE_ASPECT_RATIO);
#endif

    // generate inference result outputs
    int len = result->box_count*sizeof(struct bounding_box_s);
    if (image_p->post_flag & REDIRECT_OUTPUT) {
        // place outputs into buffer
        memcpy(image_p->post_buf_addr, result, sizeof(int)*2+len);
    } else {
        printf("class_count = %d, good_result_count: %d\n", result->class_count, result->box_count);
        for(int i = 0 ; i < result->box_count; i++) {
            printf("box[%d] [%d %d %d %d] score: %f, class: %d\n", i+1, (int)result->boxes[i].x1, (int)result->boxes[i].y1, (int)result->boxes[i].x2, (int)result->boxes[i].y2, result->boxes[i].score, result->boxes[i].class_num);
        }
    }

    return len;
}
