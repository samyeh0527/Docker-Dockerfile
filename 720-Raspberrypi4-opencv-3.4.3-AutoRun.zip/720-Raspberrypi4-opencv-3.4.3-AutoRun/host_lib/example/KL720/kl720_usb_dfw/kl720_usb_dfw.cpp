/**
 * @file        kl720_usb_dfw.cpp
 * @brief       kdp host lib user test examples
 * @version     0.1
 * @date        2021-2-26
 *
 * @copyright   Copyright (c) 2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "user_util.h"
#include "base.h"
#include <libusb-1.0/libusb.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define VENDOR_ID       0x3231
#define PRODUCT_ID_DFU  0x0720
#define bcdDevice_DFU   0x0101
#define PRODUCT_ID_DFW  0x0720
#define bcdDevice_DFW   0x00BA

#define MINION_FILE         ("../../app_binaries/KL720/dfw/usb_minion.bin")
#define SCPU_FILE           ("../../app_binaries/KL720/dfw/fw_scpu.bin")
#define NCPU_FILE           ("../../app_binaries/KL720/dfw/fw_ncpu.bin")
#define MAX_BUF_SIZE        (80 * 1024 * 1024)
#define MSG_DATA_BUF_MAX    0x4000

#define NiRAM_MEM_BASE              0x6F000000      
#define NiRAM_MEM_SIZE              0x20000         //128KB 
#define NdRAM_MEM_BASE              0x6F080000      
#define NdRAM_MEM_SIZE              0x80000         //512KB
#define NCPU_FW_SIZE                0x200000        //2MB
#define NCPU_FW_IRAM_SIZE           NiRAM_MEM_SIZE
#define NCPU_FW_DDR_BASE            0x80020000  
#define NCPU_FW_DDR_SIZE            (NCPU_FW_SIZE-NCPU_FW_IRAM_SIZE)      //2MB - 128KB

#define SCPU_START_ADDRESS                0x1FFC0000 //SiRAM_MEM_BASE
#define NCPU_START_ADDRESS                0x6F000000 //NiRAM_MEM_BASE
#define SCPU_START_ADDRESS_Flash          0x00040000
#define NCPU_START_ADDRESS_Flash          0x00060000

#define ENP_BULK_CMD_OUT  0x01
#define ENP_BULK_CMD_IN   0x82
#define ENP_BULK_DATA_OUT 0x03
#define ENP_BULK_DATA_IN  0x84

#define MSG_HDR_CMD     0xA583
#define	MSG_HDR_RSP     0x8A35
#define MSG_HDR_VAL     0xA553  // this is used by the pre-packet code
#define MSG_HDR_SIZE    16  // includes both MsgHdr and CmdPram addr & len

/* DFU commands */
#define DFU_DETACH      0
#define DFU_DNLOAD      1
#define DFU_UPLOAD      2
#define DFU_GETSTATUS   3
#define DFU_CLRSTATUS   4
#define DFU_GETSTATE    5
#define DFU_ABORT       6

typedef struct {
	uint32_t error;
	uint32_t bytes;
} RspPram_t;
typedef struct {
	uint16_t header;
	uint16_t crc16;
	uint32_t cmd;
	uint32_t addr;
	uint32_t len;
} MsgHdr_t;
typedef struct
{
	uint32_t test_id;
	uint32_t input[80]; // free to use, case by case with different cmd item
} test_cmd_t;
typedef struct
{
	uint32_t result;	 // 0 = pass, non-0 failed
	uint32_t output[20]; // free to use, case by case with different cmd item
} test_response_t;

typedef enum {
	CMD_NONE = 0,
	CMD_MEM_READ,
	CMD_MEM_WRITE,
	CMD_DATA,
	CMD_ACK,
	CMD_STS_CLR,
	CMD_MEM_CLR,
	CMD_CRC_ERR,
	CMD_TEST_ECHO,

	// Flash command
	CMD_FLASH_INFO = 0x1000,
	CMD_FLASH_CHIP_ERASE,
	CMD_FLASH_SECTOR_ERASE,
	CMD_FLASH_READ,
	CMD_FLASH_WRITE,
	CMD_SCPU_RUN,
} Cmd;

enum dfu_state {
	DFU_STATE_appIDLE		= 0,
	DFU_STATE_appDETACH		= 1,
	DFU_STATE_dfuIDLE		= 2,
	DFU_STATE_dfuDNLOAD_SYNC	= 3,
	DFU_STATE_dfuDNBUSY		= 4,
	DFU_STATE_dfuDNLOAD_IDLE	= 5,
	DFU_STATE_dfuMANIFEST_SYNC	= 6,
	DFU_STATE_dfuMANIFEST		= 7,
	DFU_STATE_dfuMANIFEST_WAIT_RST	= 8,
	DFU_STATE_dfuUPLOAD_IDLE	= 9,
	DFU_STATE_dfuERROR		= 10
};

static test_response_t gResponse;
char model_file_buffer[MAX_BUF_SIZE];
uint8_t msg_tbuf[MSG_DATA_BUF_MAX + sizeof(MsgHdr_t) + sizeof(RspPram_t) + 4];
static libusb_device_handle *dev_handle = NULL;
static int bulk_max_packet_size = 512; // default high-speed

//#define DEBUG_MSG1 1
#define CRC16_CONSTANT 0x8005
uint16_t gen_crc16(uint8_t* data, uint16_t size)
{
	uint16_t out = 0;
	int bits_read = 0, bit_flag, i;

	/* Sanity check: */
	if (data == NULL)
		return 0;

	while (size > 0)
	{
		bit_flag = out >> 15;

		/* Get next bit: */
		out <<= 1;
		out |= (*data >> bits_read) & 1; // item a) work from the least significant bits

										 /* Increment bit counter: */
		bits_read++;
		if (bits_read > 7)
		{
			bits_read = 0;
			data++;
			size--;
		}

		/* Cycle check: */
		if (bit_flag)
			out ^= CRC16_CONSTANT;

	}

	// push out the last 16 bits
	for (i = 0; i < 16; ++i) {
		bit_flag = out >> 15;
		out <<= 1;
		if (bit_flag)
			out ^= CRC16_CONSTANT;
	}

	// reverse the bits
	uint16_t crc = 0;
	i = 0x8000;
	int j = 0x0001;
	for (; i != 0; i >>= 1, j <<= 1) {
		if (i & out) crc |= j;
	}

	return crc;
}

static int usb_bulk_out_kl720(libusb_device_handle *usbdev, unsigned char endpoint, unsigned char* buf, int num, int timeout)
{
	int status;
	int transferred;
	status = libusb_bulk_transfer(usbdev, endpoint, buf, num, &transferred, timeout);
	if (status != 0)
	{
		printf("libusb_bulk_transfer() error, status %d\n", status);
		return status;
	}
	else if (num != transferred)
	{
		printf("[khost_usb] bulk transfer size mismatch: %d vs %d\n", num, transferred);
		return status; // FIXME
	}

	// sending fake ZLP due to Faraday FOTG330 limitation
	if ((num % bulk_max_packet_size) == 0)
	{
		unsigned int fake_ZLP = 0x11223344;
		status = libusb_bulk_transfer(usbdev, endpoint, (unsigned char *)&fake_ZLP, 4, &transferred, 0);
		if (status != 0)
		{
			printf("[khost_usb] send fake ZLP failed error: %s\n", libusb_strerror((enum libusb_error)status));
			return status;
		}
	}

	return status;
}

static int usb_bulk_in_kl720(libusb_device_handle *usbdev, unsigned char endpoint, unsigned char* buf, int buf_size, int *recv_size, int timeout)
{
	int status = libusb_bulk_transfer(usbdev, endpoint, buf, buf_size, recv_size, timeout);
	if (status != 0)
	{
		printf("[khost_usb] recv data failed error: %s\n", libusb_strerror((enum libusb_error)status));
		return status;
	}

	return status;
}

static void cmd_file_send(uint32_t cmd, unsigned char* p_buf, long file_size, uint32_t index)
{
	int recv_len = 0;
	MsgHdr_t msghdr;
	unsigned char fw_buf[MSG_DATA_BUF_MAX + MSG_HDR_SIZE];
	int dfw_count = file_size / MSG_DATA_BUF_MAX;
	uint32_t len = file_size < MSG_DATA_BUF_MAX ? file_size : MSG_DATA_BUF_MAX;
	//printf("******  unit length %d repeat count %d  ******\n",len, dfw_count);
	if (((file_size % MSG_DATA_BUF_MAX) != 0) || (file_size == 0))
		dfw_count++;
	for (int repeat = 0; repeat < dfw_count; repeat++)
	{
#ifdef DEBUG_MSG1
		printf("******  repeat count %d  ******\n", repeat);
		printf("=========================================\n");
#endif
		memcpy(&fw_buf[MSG_HDR_SIZE], (p_buf + (repeat * MSG_DATA_BUF_MAX)), len);
		msghdr.header = MSG_HDR_CMD;
		msghdr.crc16 = 0;
		msghdr.cmd = cmd;
		msghdr.addr = index + (repeat * MSG_DATA_BUF_MAX);
		msghdr.len = len;
		memcpy(&fw_buf[0], &msghdr, MSG_HDR_SIZE);
		msghdr.crc16 = gen_crc16(&fw_buf[4], (len + MSG_HDR_SIZE - 4));
		memcpy(&fw_buf[2], &msghdr.crc16, 2);
#ifdef DEBUG_MSG1
		for (uint32_t i = 0; i < (len + MSG_HDR_SIZE); i++)
		{
			printf("%X ", fw_buf[i]);
			if ((i != 0) && ((i % 32) == 0))
				printf("\n");
		}
#endif
        unsigned char* fw_buf_addr = &fw_buf[0];
		usb_bulk_out_kl720(dev_handle, ENP_BULK_CMD_OUT, fw_buf_addr, (len + MSG_HDR_SIZE), 0);
#ifdef DEBUG_MSG1
		printf("\n========usb_bulk_out_kl720 SEND!========\n");
#endif
        //unsigned char* Response = (unsigned char*)&gResponse;
		usb_bulk_in_kl720(dev_handle, ENP_BULK_CMD_IN, (unsigned char*)&gResponse, sizeof(gResponse), &recv_len, 0);
		if (gResponse.result != 0)
			break;
#ifdef DEBUG_MSG1
		printf(" %s\n", (gResponse.result == 0) ? "PASSED" : "FAILED");
		printf("\n");
		printf("\n=========================================\n");
#endif
	}
}

static int dfu_get_status(libusb_device_handle *dev_idx)
{
	int length = 6;
	unsigned char data[0x10];
	libusb_control_transfer(dev_idx, LIBUSB_ENDPOINT_IN | LIBUSB_REQUEST_TYPE_CLASS | LIBUSB_RECIPIENT_INTERFACE, DFU_GETSTATUS, 0, 0, data, (uint16_t)length, 1000);
    return data[4];
}

static int load_minion_file(libusb_device_handle *dev_idx, char *file)
{
    int ret;
    int model_size;
    unsigned char* p_buf;

    p_buf = new unsigned char[MAX_BUF_SIZE];
    ret = read_file_to_buf((char *)p_buf, file, MAX_BUF_SIZE);
    if (ret <= 0) {
        printf("reading file failed: %d\n", ret);
        return ret;
    }

    model_size = ret;
    printf("starting loading file ...");

	int cnt = 0;
	long dfu_size;
    int dfu_status = -1;
	while (model_size)
	{
        dfu_status =  dfu_get_status(dev_idx);
		if(dfu_status!=DFU_STATE_dfuERROR)
        {
		    dfu_size = (model_size > 2048) ? 2048 : model_size;
		    libusb_control_transfer(dev_idx, LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_CLASS | LIBUSB_RECIPIENT_INTERFACE, DFU_DNLOAD, cnt, 0, p_buf+(cnt*2048), (uint16_t)dfu_size, 1000);
		    model_size = model_size - dfu_size;
		    cnt++;
        }
        else //if(dfu_status==DFU_STATE_dfuERROR)
        {
            printf("usb dfu device report ERROR STATE\n");
        }
	}
	dfu_status =  dfu_get_status(dev_idx);
    if(dfu_status!=DFU_STATE_dfuERROR)
	    libusb_control_transfer(dev_idx, LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_STANDARD | LIBUSB_REQUEST_TYPE_CLASS, DFU_DNLOAD, cnt, 0, NULL, 0, 1000);
    else //if(dfu_status==DFU_STATE_dfuERROR)
    {
        printf("usb dfu device report ERROR STATE\n");
    }

    do {
        dfu_status = dfu_get_status(dev_idx);
    } while(dfu_status!=DFU_STATE_appIDLE);
    //libusb_control_transfer(dev_idx, LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_CLASS | LIBUSB_RECIPIENT_INTERFACE, DFU_DETACH, 1000, 0, NULL, 0, 1000);
    libusb_reset_device(dev_idx);
    libusb_close(dev_idx);

    printf(" done\n");
    delete[] p_buf;
    return 0;
}

int user_test(libusb_device_handle *dev_idx, char *minion)
{
    int ret;

    double start_time = what_time_is_it_now();

    ret = load_minion_file(dev_idx, minion);

    double end_time = what_time_is_it_now();
    double elapsed_time = end_time - start_time;
    printf("=> Time = %.3f seconds\n\n", elapsed_time);

    return ret;
}

static void usage(char *name)
{
    printf("\n");
    printf("usage: %s [minion path]\n", name);
    printf("\n[reset mode] default: MINION_FILE minion path: specified minion path\n");
}

static int find_device(int PID, int bcdDevice)
{
	while (1)
	{
		printf("Cannot connect to KL720 device (PID 0x%04x)\n", PID);
		printf("If the device is connected, please check if the WinUSB driver has been installed\n");
        #ifdef __linux__
            sleep(1);
        #else
            Sleep(1000);
        #endif
		dev_handle = libusb_open_device_with_vid_pid(NULL, VENDOR_ID, PID);
		//return NULL;
		if(dev_handle)
		{
			libusb_device *dev = libusb_get_device(dev_handle);
			struct libusb_device_descriptor desc;
			int r = libusb_get_device_descriptor(dev, &desc);
			if(r < 0)
			    continue;
			printf("========bcdDevice 0x%X========\n", desc.bcdDevice);
			if(bcdDevice == desc.bcdDevice)
			    break;
		}
	}

	libusb_device *dev = libusb_get_device(dev_handle);
	int link_speed = libusb_get_device_speed(dev);
	if (link_speed >= LIBUSB_SPEED_SUPER)
		bulk_max_packet_size = 1024;

	int status = libusb_set_configuration(dev_handle, 1);
	if (status)
	{
		printf("ERROR: libusb_set_configuration() failed: %s\n", libusb_strerror((enum libusb_error)status));
		return -1;
	}

	status = libusb_claim_interface(dev_handle, 0);
	if (status)
	{
		printf("ERROR: libusb_claim_interface() failed: %s\n", libusb_strerror((enum libusb_error)status));
		return -1;
	}
	printf("Connected to KL720 device (0x3231 0x%04x) at %s.\n\n", PID, (link_speed >= LIBUSB_SPEED_SUPER) ? "Super-Speed" : "High-Speed");
    return 0;
}


int main(int argc, char *argv[])
{
    char *minion;

    if (argc == 1) {
        usage(argv[0]);
        minion = (char *)MINION_FILE;
        printf("\nUse the minion file in app_binaries/KL720/dfw by default\n");
    } else if (argc == 2) {
        minion = (char *)argv[1];
        printf("\nUse the minion file: %s\n", minion);
    } else {
        usage(argv[0]);
        return -1;
    }
    printf("init kdp host lib log....\n");

    if (kdp_lib_init() < 0)
    {
        printf("init for kdp host lib failed.\n");
        return -1;
    }

	//==========================================================================================
	printf("1. start dfu-util-static to download usb_minion.bin..\n");
    if (find_device(PRODUCT_ID_DFU,bcdDevice_DFU) < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    printf("start usb minion....\n");
    if (kdp_lib_start() < 0)
    {
        printf("start usb minion failed.\n");
        return -1;
    }

    load_minion_file(dev_handle, minion);

	//==========================================================================================
	printf("2. usb_minion takes the handle..\n");
    if (find_device(PRODUCT_ID_DFW,bcdDevice_DFW) < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    int ret;
    int file_size;
    unsigned char* p_buf;

    p_buf = new unsigned char[MAX_BUF_SIZE];
    ret = read_file_to_buf((char *)p_buf, SCPU_FILE, MAX_BUF_SIZE);
    if (ret <= 0) {
        printf("reading scpu fw failed: %d\n", ret);
        return ret;
    }

    file_size = ret;
    printf("starting loading scpu fw ...\n");
	printf("DFW SCPU FW...\n");
	cmd_file_send(CMD_MEM_WRITE, p_buf, file_size, SCPU_START_ADDRESS);
	printf("Verifying SCPU FW...\n");
	cmd_file_send(CMD_MEM_READ, p_buf, file_size, SCPU_START_ADDRESS);
	printf("DFW SCPU FW %s!!!!\n", (gResponse.result == 0) ? "PASSED" : "FAILED");

    ret = read_file_to_buf((char *)p_buf, NCPU_FILE, MAX_BUF_SIZE);
    if (ret <= 0) {
        printf("reading ncpu fw failed: %d\n", ret);
        return ret;
    }
    file_size = ret;
	printf("DFW NCPU FW...\n");
	cmd_file_send(CMD_MEM_WRITE, p_buf, NiRAM_MEM_SIZE, NCPU_START_ADDRESS);
	printf("Verifying NCPU FW...\n");
	cmd_file_send(CMD_MEM_READ, p_buf, NiRAM_MEM_SIZE, NCPU_START_ADDRESS);
	printf("DFW NCPU FW %s!!!!\n", (gResponse.result == 0) ? "PASSED" : "FAILED");
	printf("DFW NCPU-DDR FW...\n");
	cmd_file_send(CMD_MEM_WRITE, p_buf+ NiRAM_MEM_SIZE, NCPU_FW_DDR_SIZE, NCPU_FW_DDR_BASE);
	printf("Verifying NCPU-DDR FW...\n");
	cmd_file_send(CMD_MEM_READ, p_buf + NiRAM_MEM_SIZE, NCPU_FW_DDR_SIZE, NCPU_FW_DDR_BASE);
	printf("DFW NCPU-DDR FW %s!!!!\n", (gResponse.result == 0) ? "PASSED" : "FAILED");

	//==========================================================================================
	/* BOOT UP */
    MsgHdr_t *msghdr;
    msghdr = (MsgHdr_t *)msg_tbuf;
	msghdr->header = MSG_HDR_CMD;
	msghdr->crc16 = 0;
	msghdr->cmd = CMD_SCPU_RUN;
	msghdr->len = 0;
	msghdr->addr = SCPU_START_ADDRESS;
	msghdr->crc16 = gen_crc16(( uint8_t*)(msg_tbuf + 4), MSG_HDR_SIZE - 4);

	printf("send scpu_run command to boot from 0x%x\n", msghdr->addr);
	usb_bulk_out_kl720(dev_handle, ENP_BULK_CMD_OUT, (unsigned char*)&msg_tbuf, MSG_HDR_SIZE, 0);
	//==========================================================================================
    libusb_close(dev_handle);
    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
