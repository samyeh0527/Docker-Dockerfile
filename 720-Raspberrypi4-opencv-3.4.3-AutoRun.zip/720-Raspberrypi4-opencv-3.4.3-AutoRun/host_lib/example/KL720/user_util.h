/**
 * @file        user_util.h
 * @brief       kdp host lib user test header file
 * @version     0.1
 * @date        2019-08-01
 *
 * @copyright   Copyright (c) 2019-2021 Kneron Inc. All rights reserved.
 */


#ifndef __USER_UTIL__H__
#define __USER_UTIL__H__
#include <stdint.h>
#include <signal.h>
#if defined (__cplusplus) || defined (c_plusplus)
extern "C"{
#endif

#define TEST_DFU_DIR                  "../../app_binaries/KL720/dfu/"
#define MAX_ISI_DATA_SIZE  0x130000

#define IMAGE_SIZE (640*480*2)
#define SLEEP_TIME 1000
#define HOSTLIB_SIG  SIGINT | SIGTERM 

// Supported conversion formats for kdp_cvt_color
#define RGB565_TO_BGR888        1
#define YUV422_TO_BGR888        2

typedef struct test_img
{
    char *file_name;
    int image_size;	
} test_img_t;


bool check_ctl_break(void);
int register_hostlib_signal(void);
int write_buf_to_file(char* buf, const char* fn, uint32_t size);
int read_file_to_buf(char* buf, const char* fn, int nlen);
int read_file_to_buf_2(char** buf, const char* fn);
test_img_t* create_batch_image_file_list(char *img_or_dir_name, int *total_files);
int export_result_to_file(char *out_buf, uint32_t buf_len, char *img, char *res_name);
char* lookup_model_name(uint32_t model_id);
double what_time_is_it_now();
struct kdp_dme_cfg_s create_dme_cfg_struct();
struct kdp_isi_cfg_s create_isi_cfg_struct();
struct kdp_metadata_s create_metadata_struct();
int kdp_cvt_color(void* dst, void* src, int src_len, int fmt2fmt);

/// @brief (CI only) prepare ci_logfile_name
/// @details [executable_name].log will be generated
///
/// @param argc main's argc
/// @param argv main's argv
/// @returen ci_log_file_name
///
const char* ci_prepare_logfile_name(int argc, char*argv[]);

/// @brief (CI only) print data to log file 
/// @details [executable_name].log will be generated
///
/// @param fmt printf format
/// @param ... printf arguments list 
/// @returen true if no error
///
bool print2log(const char* fmt, ...);
#if defined (__cplusplus) || defined (c_plusplus)
}
#endif

#endif
