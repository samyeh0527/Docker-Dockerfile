/**
 * @file        kl720_cam_isi_center_app.cpp
 * @brief       kdp host lib user test examples
 * @version     0.5
 * @date        2021-02-10
 *
 * @copyright   Copyright (c) 2020-2021-2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/stat.h>
#include "user_util.h"
#include "kapp_id.h"
#include "model_res.h"
#include "model_type.h"
#include "base.h"
#include "ipc.h"
#include "post_processing_ex.h"
#include "kdpio.h"

#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <vector>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C"
{

using namespace std;
using namespace cv;
#endif

uint32_t round_up(uint32_t num);
int post_yolo_v3(int model_id, struct kdp_image_s* image_p);
int post_yolo_v5(int model_id, struct kdp_image_s* image_p);
int post_yolo_custom(int model_id, struct kdp_image_s* image_p);
int post_imgnet_classification(int model_id, struct kdp_image_s* image_p);

//#define TEST_CHECK_FRAME_TIME
#define ISI_APP_ID          APP_CENTER_APP
#define ISI_RESULT_SIZE     0x240000
#define ISI_IMG_FORMAT      (IMAGE_FORMAT_SUB128 | NPU_FORMAT_RGB565 | IMAGE_FORMAT_CHANGE_ASPECT_RATIO)
#define VIDEO_MODES         3

static char inf_res[ISI_RESULT_SIZE];
//static char *inf_res_raw = inf_res;
static struct post_parameter_s post_par;
struct kdp_image_s  image_s = { 0 };
struct kdp_image_s* image_p = &image_s;
float  ext_param[MAX_PARAMS_LEN];
dme_yolo_res  det_res_s = { 0 };
dme_yolo_res* det_res = (dme_yolo_res *)&det_res_s;

struct video_array {
    int     width;
    int     height;
    int     size;
} img_s[VIDEO_MODES] = {
    {640, 480, 640*480*2},  // VGA
    {800, 600, 800*600*2},   // SVGA
    {1280, 720, 1280*720*2}   // WXGA
};

#define MIN_SCORE_YOLOv3        (0.15f)
#define MIN_SCORE_YOLOv5        (0.15f)
#define MIN_SCORE_DEFAULT       (0.35f)

VideoCapture cap;
vector<Mat> frames;

uint32_t model_id = KNERON_OBJECTDETECTION_CENTERNET_512_512_3;
uint32_t post_mode = 0;  // DSP mode is default
float model_threshold = 0;
char caption[80];

static od_post_params_t post_proc_params_v5s = {
    .prob_thresh = 0.15,
    .nms_thresh = 0.45,
    .max_detection_per_class = 20,
    .anchor_row = 3,
    .anchor_col = 6,
    .stride_size = 3,
    .reserved_size = 0,
    .data = {
        // anchors[3][6]
        10, 13, 16, 30, 33, 23,
        30, 61, 62, 45, 59, 119,
        116, 90, 156, 198, 373, 326,
        // strides[3]
        8, 16, 32,
    },
};

static od_post_params_t post_proc_params_cust3 = {
    .prob_thresh = 0.2,
    .nms_thresh = 0.45,
    .max_detection_per_class = 20,
    .anchor_row = 3,
    .anchor_col = 6,
    .stride_size = 0,
    .reserved_size = 0,
    .data = {
        // anchors[3][6]
        5, 5, 9, 11, 15, 18,
        26, 34, 44, 58, 60, 143,
        140, 122, 186, 342, 430, 365,
    },
};

static od_post_params_t post_proc_params_cust4 = {
    .prob_thresh = 0.15,
    .nms_thresh = 0.45,
    .max_detection_per_class = 20,
    .anchor_row = 3,
    .anchor_col = 6,
    .stride_size = 3,
    .reserved_size = 0,
    .data = {
        // anchors[3][6]
        5, 5, 9, 11, 15, 18,
        26, 34, 44, 58, 60, 143,
        140, 122, 186, 342, 430, 365,
        // strides[3]
        8, 16, 32,
    },
};

static int do_inference(int dev_idx, char *img_buf, int buf_len, uint32_t img_id, uint32_t *rsp_code, uint32_t *window_left)
{
    int ret;

    ret = kdp_isi_inference(dev_idx, img_buf, buf_len, img_id, rsp_code, window_left);
    if (ret)
    {
        printf("ISI inference failed : %d\n", ret);
        return -1;
    }
    if (*rsp_code != 0)
    {
        printf("ISI inference error_code: [%d] [%d]\n", *rsp_code, *window_left);
        return -1;
    }

    return 0;
}

#ifdef TEST_CHECK_FRAME_TIME
static void do_check_frame_time(void)
{
    static double last_time = 0;
    double cur_time, elapsed_time;

    if (last_time == 0)
    {
        // skip first one
        last_time = what_time_is_it_now();
        return;
    }

    cur_time = what_time_is_it_now();
    elapsed_time = (cur_time - last_time) * 1000;

    printf("--> frame time %.2f ms\n", (float)elapsed_time);
    last_time = what_time_is_it_now();
}
#endif

static int cam_open(int video_mode)
{
    if (!cap.open(0))
    {
        printf("Unable to connect to camera.\n");
        return -1;
    }

    bool b_set_width = cap.set(CV_CAP_PROP_FRAME_WIDTH, img_s[video_mode].width);
    bool b_set_height = cap.set(CV_CAP_PROP_FRAME_HEIGHT, img_s[video_mode].height);
    if (false == b_set_width || false == b_set_height)
    {
        printf("Unable to set resolution (%d,%d) to camera.\n", img_s[video_mode].width, img_s[video_mode].height);
        return -1;
    }
    int n_get_width = cap.get(CV_CAP_PROP_FRAME_WIDTH);
    int n_get_height = cap.get(CV_CAP_PROP_FRAME_HEIGHT);
    if (n_get_width != img_s[video_mode].width || n_get_height != img_s[video_mode].height)
    {
        printf("Unsupported resolution in camera!!!\n");
        printf("(%d,%d) => resolution to set\n", img_s[video_mode].width, img_s[video_mode].height);
        printf("(%d,%d) => get resolution after set\n", n_get_width, n_get_height);
        return -1;
    }

    return 0;
}

/**
 * capture a new frame from camera
 * cap: video capturing device
 * return frame in IplImage format
 */
static IplImage cam_capture_frame(VideoCapture cap)
{
    Mat frame_input;
    // capture a new frame from camera
    cap >> frame_input;
    // convert frame from BGR to RGB565
    cvtColor(frame_input, frame_input, CV_BGR2BGR565);
    // flip the frame
    flip(frame_input, frame_input, 1);
    // save the frame into vector of frames for displaying
    frames.push_back(frame_input);
    // return frame in IplImage format
#if CV_MAJOR_VERSION > 3 || (CV_MAJOR_VERSION == 3 && CV_SUBMINOR_VERSION >= 9)
    return cvIplImage(frame_input);
#else
    return (IplImage)frame_input;
#endif
}

static string get_local_time(void)
{
    string default_time = "19700101_000000.000";
    try
    {
        struct timeval cur_time;
        gettimeofday(&cur_time, NULL);
        int milli = cur_time.tv_usec / 1000;

        char buffer[80] = {0};
        struct tm now_time;
        time_t tv_sec = cur_time.tv_sec;
        localtime_r(&tv_sec, &now_time);
        strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", &now_time);

        char current_time[84] = {0};
        snprintf(current_time, sizeof(current_time), "%s.%03d", buffer, milli);

        return current_time;
    }
    catch(const std::exception& e)
    {
        return default_time;
    }
    catch (...)
    {
        return default_time;
    }
}

static void create_dir(const char* dir_name)
{
    if (0 != access(dir_name, F_OK))
    {
#ifdef __linux__
        int flag = mkdir(dir_name, 0777);
#elif _WIN32
        int flag = mkdir(dir_name);
#endif
        if (flag < 0)
        {
            printf("create directory: %s failed!\n", dir_name);
        }
    }
}

static int handle_key_pressed(char key, Mat front_frame_raw, Mat front_frame_bb)
{
    int ret = 0;
    char image[84] = {0}; // raw image
    char image_bb[84] = {0}; // image with bounding box
    const char SAVE_IMAGE_DIR[] = "kl720_cam_isi_center_app_imgs";

    if (key == 0xff)  // check for timeout
        return 0;

    switch (key)
    {
    case 's':
    case 'S':
    case 'b':
        create_dir(SAVE_IMAGE_DIR);
        string now = get_local_time();
        snprintf(image, sizeof(image), "%s/%s.jpg", SAVE_IMAGE_DIR, now.c_str());
        snprintf(image_bb, sizeof(image_bb), "%s/%s_bb.jpg", SAVE_IMAGE_DIR, now.c_str());
        break;
    }

    switch (key)
    {
    case 's': // save raw image
        cvtColor(front_frame_raw, front_frame_raw, CV_BGR5652BGR);
        imwrite(image, front_frame_raw);
        break;
    case 'S': // save image with bounding box
        imwrite(image_bb, front_frame_bb);
        break;
    case 'b': // save both raw image and image with bounding box
        cvtColor(front_frame_raw, front_frame_raw, CV_BGR5652BGR);
        imwrite(image, front_frame_raw);
        imwrite(image_bb, front_frame_bb);
        break;
    default: // exit
        ret = 1;
        break;
    }
    return ret;
}

static int cam_show_detection(int img_id, char* inf_res)
{
    // parse the detection result
    dme_res* detection_res = (dme_res*)inf_res;
    uint32_t box_count = detection_res->box_count;
    struct bounding_box_s* box;
    uint32_t i;
    Mat front_frame_raw = frames.front();
    Mat front_frame = frames.front();
    Scalar color;

    printf("image %d -> %d object(s)\n", img_id, box_count);

    // draw detection on the frame
    cvtColor(front_frame, front_frame, CV_BGR5652BGR);
    box = &detection_res->boxes[0];
    for (i = 0; i < box_count; i++) {
        if (box->class_num == 0 /*person*/)
            color = Scalar(255, 0, 0);
        else
            color = Scalar(255, 255, 0);
        rectangle(front_frame, Point(box->x1, box->y1), Point(box->x2, box->y2), color, 2);
        printf("  [%d] {%d: %f}: (%d, %d) (%d, %d)\n", i, box->class_num, box->score,
                    (int)box->x1, (int)box->y1, (int)box->x2, (int)box->y2);
        box++;
    }

    // show detection in window
    imshow(caption, front_frame);

    // delete the first frame after showing detection
    vector<Mat>::iterator first_frame = frames.begin();
    frames.erase(first_frame);
    // exit when pressing any key
    char key = (char) waitKey(1);
    if (key >= 0) {
        return handle_key_pressed(key, front_frame_raw, front_frame);
    }
    return 0;
}

static int do_get_result(int dev_idx, uint32_t img_id, uint32_t *rsp_code, uint32_t *r_size, char *r_data)
{
    int ret;

    memset(r_data, 0, 8); // initialize results data

    ret = kdp_isi_retrieve_res(dev_idx, img_id, rsp_code, r_size, r_data);
    if (ret)
    {
        printf("ISI get [%d] result failed : %d\n", img_id, ret);
        return -1;
    }

    if (*rsp_code != 0)
    {
        printf("ISI get [%d] result error_code: [%d] [%d]\n", img_id, *rsp_code, *r_size);
        return -1;
    }

    if (post_mode)  // raw mode
    {
        // struct imagenet_result_s* imgnet_res;
        raw_cnn_res_t* pRes;
        raw_onode_t* pNode;

        // Prepare for postprocessing
        pRes = (raw_cnn_res_t*)r_data;
        int output_num = pRes->total_nodes;

        uint32_t r_len, offset;
        offset = sizeof(raw_cnn_res_t);

        // Struct to pass the parameters
        RAW_INPUT_COL(image_p) = post_par.raw_input_col;
        RAW_INPUT_ROW(image_p) = post_par.raw_input_row;
        DIM_INPUT_COL(image_p) = post_par.model_input_col;
        DIM_INPUT_ROW(image_p) = post_par.model_input_row;
        RAW_FORMAT(image_p) = post_par.image_format;
        POSTPROC_RESULT_MEM_ADDR(image_p) = (uint32_t*)det_res;
        image_p->post_buf_addr = r_data;
        image_p->post_flag |= REDIRECT_OUTPUT;
        POSTPROC_OUTPUT_NUM(image_p) = output_num;
        for (int i = 0; i < output_num; i++) {
            pNode = &pRes->onode_a[i];
            r_len = pNode->ch_length * pNode->row_length * round_up(pNode->col_length);
            POSTPROC_OUT_NODE_ADDR(image_p, i) = r_data + offset;
            POSTPROC_OUT_NODE_ROW(image_p, i) = pNode->row_length;
            POSTPROC_OUT_NODE_CH(image_p, i) = pNode->ch_length;
            POSTPROC_OUT_NODE_COL(image_p, i) = pNode->col_length;
            POSTPROC_OUT_NODE_RADIX(image_p, i) = pNode->output_radix;
            POSTPROC_OUT_NODE_SCALE(image_p, i) = pNode->output_scale;
            offset = offset + r_len;
        }

        switch (model_id) {
            case TINY_YOLO_V3_416_416_3:
            case TINY_YOLO_V3_608_608_3:
            case YOLO_V3_416_416_3:
            case YOLO_V3_608_608_3:
                post_yolo_v3(model_id, image_p);
                break;
            case KNERON_YOLOV5S_640_640_3:
            case KNERON_YOLOV5M_640_640_3:
            case KNERON_PERSONDETECTION_YOLOV5s_480_256_3:
            case KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3:
            case CUSTOMER_MODEL_4:
                post_yolo_v5(model_id, image_p);
                break;
            default:
                post_mode = 0;  // turn off raw mode
                break;
        }
    }

    if (*r_size >= sizeof(uint32_t))
    {
#ifdef TEST_CHECK_FRAME_TIME
        do_check_frame_time();
#endif

        switch (model_id) {
        case KNERON_OBJECTDETECTION_CENTERNET_512_512_3:
        case TINY_YOLO_V3_416_416_3:
        case TINY_YOLO_V3_608_608_3:
        case YOLO_V3_416_416_3:
        case YOLO_V3_608_608_3:
        case YOLO_V4_416_416_3:
        case KNERON_YOLOV5S_640_640_3:
        case KNERON_FD_MBSSD_200_200_3:
        case CUSTOMER_MODEL_1:
        case CUSTOMER_MODEL_2:
        case CUSTOMER_MODEL_3:
        case CUSTOMER_MODEL_4:
        case KNERON_PERSONDETECTION_YOLOV5s_480_256_3:
        case KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3:
        case KNERON_YOLOV5M_640_640_3:
            ret = cam_show_detection(img_id, r_data);
            break;

        default:
            printf("Wrong model ID %d with size %d\n", model_id , *r_size);
            break;
        }
    }
    else
    {
        printf("Img [%d] : result_size %d too small\n", img_id, *r_size);
        return -1;
    }

    return ret;
}

static int user_test_centernet(int dev_idx, int video_mode, uint32_t test_loop)
{
    int ret = 0;
    uint32_t error_code = 0;
    uint32_t image_buf_size = 0;

    if (cam_open(video_mode))
        return -1;

    sprintf(caption, "Center App (%d x %d)", img_s[video_mode].width, img_s[video_mode].height);

    if (1)
    {
        // isi configuration
        struct kdp_isi_cfg_s isi_cfg = create_isi_cfg_struct();
        int cfg_size = sizeof(struct kdp_isi_cfg_s);

        isi_cfg.app_id = ISI_APP_ID;
        isi_cfg.res_buf_size = ISI_RESULT_SIZE;
        isi_cfg.image_col = img_s[video_mode].width;
        isi_cfg.image_row = img_s[video_mode].height;
        isi_cfg.image_format = ISI_IMG_FORMAT;

        if (post_mode) {
            switch (model_id) {
            case TINY_YOLO_V3_416_416_3:
            case YOLO_V3_416_416_3:
                post_par.model_input_row = 416;
                post_par.model_input_col = 416;
                break;
            case TINY_YOLO_V3_608_608_3:
            case YOLO_V3_608_608_3:
                post_par.model_input_row = 608;
                post_par.model_input_col = 608;
                break;
            case KNERON_YOLOV5S_640_640_3:
            case KNERON_YOLOV5M_640_640_3:
            case CUSTOMER_MODEL_3:
            case CUSTOMER_MODEL_4:
                post_par.model_input_row = 640;
                post_par.model_input_col = 640;
                break;
            case KNERON_PERSONDETECTION_YOLOV5s_480_256_3:
            case KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3:
                post_par.model_input_row = 480;
                post_par.model_input_col = 256;
                break;
            default:
                printf("RAW mode not supported for model %d\n", model_id);
                post_mode = 0;  // turn off raw mode
                break;
            }
            memset(ext_param, 0, sizeof(ext_param[MAX_PARAMS_LEN]));
            if (post_mode)
                isi_cfg.image_format |= IMAGE_FORMAT_RAW_OUTPUT;
            post_par.raw_input_row = isi_cfg.image_row;
            post_par.raw_input_col = isi_cfg.image_col;
            post_par.threshold = isi_cfg.ext_param[0];

        }

        switch (model_id) {
        case TINY_YOLO_V3_416_416_3:
        case TINY_YOLO_V3_608_608_3:
        case YOLO_V3_416_416_3:
        case YOLO_V3_608_608_3:
            isi_cfg.ext_param[0] = MIN_SCORE_YOLOv3;
            break;
        case KNERON_YOLOV5S_640_640_3:
        case KNERON_YOLOV5M_640_640_3:
        case KNERON_PERSONDETECTION_YOLOV5s_480_256_3:
        case KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3:
            memcpy((void*)isi_cfg.ext_param, (void*)&post_proc_params_v5s, MAX_PARAMS_LEN * sizeof(float));
            break;
        case CUSTOMER_MODEL_3:
            memcpy((void*)isi_cfg.ext_param, (void*)&post_proc_params_cust3, MAX_PARAMS_LEN * sizeof(float));
            break;
        case CUSTOMER_MODEL_4:
            memcpy((void*)isi_cfg.ext_param, (void*)&post_proc_params_cust4, MAX_PARAMS_LEN * sizeof(float));
            break;
        default:
            isi_cfg.ext_param[0] = MIN_SCORE_DEFAULT;
            break;
        }

        printf("starting ISI mode ...\n");
        int ret = kdp_start_isi_mode_ext(dev_idx, (char*)&isi_cfg, cfg_size, &error_code, &image_buf_size);
        if (ret != 0)
        {
            printf("could not set to ISI mode: %d ..\n", ret);
            return -1;
        }

        if (image_buf_size < 3)
        {
            printf("ISI mode window %d too small...\n", image_buf_size);
            return -1;
        }

        printf("Config RAM model %d...\n", model_id);
        ret = kdp_isi_config(dev_idx, model_id, 0, &error_code);

        if (ret != 0 || error_code)
        {
            printf("Config failed for model %d: %d, %d\n", model_id, ret, error_code);
            //model_id = KNERON_OBJECTDETECTION_CENTERNET_512_512_3;
            printf("Config from FLASH model %d...\n", model_id);
            ret = kdp_isi_config(dev_idx, model_id, CONFIG_USE_FLASH_MODEL, &error_code);
            if (ret != 0 || error_code) {
                printf("Config failed for model %d...\n", model_id);
                return -1;
            }
        }

        printf("ISI model %d succeeded (window = %d)...\n", model_id, image_buf_size);
        usleep(SLEEP_TIME);
    }

    if (1)
    {
        printf("starting ISI inference ...\n");
        uint32_t img_id_tx = 1;
        uint32_t img_id_rx = img_id_tx;
        uint32_t img_left = 12;
        uint32_t result_size = 0;
        uint32_t buf_len = img_s[video_mode].size;
        IplImage ipl_img;

        double start_time = what_time_is_it_now();

        uint32_t loop = test_loop;

        while (1)
        {
            ipl_img = cam_capture_frame(cap);

            ret = do_inference(dev_idx, (char*)ipl_img.imageData, buf_len, img_id_tx, &error_code, &img_left);
            if (ret)
                return ret;
            img_id_tx++;

            ret = do_get_result(dev_idx, img_id_rx, &error_code, &result_size, inf_res);
            if (ret) {
                printf("Stopped.\n");
                break;
            }
            img_id_rx++;

            loop--;
            if (loop == 0)
                break;

            if (check_ctl_break()) {
                printf("Ctrl-C received. Exit.\n");
                break;
            }
        }

        if (1)
        {
            double end_time = what_time_is_it_now();
            double elapsed_time, avg_elapsed_time, avg_fps;
            uint32_t actual_loop;

            if (test_loop)
                actual_loop = test_loop - loop;
            else
                actual_loop = ((uint32_t)(-1) - loop) + 1;
            elapsed_time = (end_time - start_time) * 1000;
            avg_elapsed_time = elapsed_time / actual_loop;
            avg_fps = 1000.0f / avg_elapsed_time;

            printf("\n=> Avg %.2f FPS (%.2f ms = %.2f/%d)\n\n",
                    avg_fps, avg_elapsed_time, elapsed_time, actual_loop);
        }
    }
    return 0;
}

static void usage(char *name)
{
    printf("\n");
    printf("usage: ./%s [video mode] [run_frames] [model_id] [post mode]\n\n", name);
    printf("[video mode] 0: vga (640x480), 1: svga (800x600), 2: wxga (1280x720)\n");
    printf("[run_frames] number of frames (> 0) to run\n");
    printf("[model_id] model ID (optional. Default is 200 for CenterNet.)\n");
    printf("[postproc] 0: postprocess at ncpu, 1: postprocess by host\n");
//    printf("[threshold] 0: use default, or new value (thrsd < 1.0)\n");
}

int main(int argc, char *argv[])
{
    if (argc < 3 || argc > 5) {  // TODO: change to 6 when adding threshold
        usage(argv[0]);
        return -1;
    }

    int video_mode = atoi(argv[1]);
    if (video_mode >= VIDEO_MODES) {
        usage(argv[0]);
        return -1;
    }
    int run_frames = atoi(argv[2]);
    if (!run_frames)
        return 0;

    if (argc >= 4)
        model_id = atoi(argv[3]);

    if (argc >= 5)
        post_mode = atoi(argv[4]);

    if (argc == 6)
        model_threshold = atof(argv[5]);

    printf("init kdp host lib log....\n");

    if (kdp_lib_init() < 0)
    {
        printf("init for kdp host lib failed.\n");
        return -1;
    }

    printf("adding devices....\n");
    int dev_idx = kdp_connect_usb_device(1);
    if (dev_idx < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    printf("start kdp host lib....\n");
    if (kdp_lib_start() < 0)
    {
        printf("start kdp host lib failed.\n");
        return -1;
    }

    register_hostlib_signal();
    user_test_centernet(dev_idx, video_mode, run_frames);

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
