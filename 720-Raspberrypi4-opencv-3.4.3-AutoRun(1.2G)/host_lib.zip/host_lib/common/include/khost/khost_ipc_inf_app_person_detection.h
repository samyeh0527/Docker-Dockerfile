/**
 * @file        khost_ipc_inf_app_person_detection.h
 * @brief       
 * @version     0.1
 * @date        2021-03-22
 *
 * @copyright   Copyright (c) 2021 Kneron Inc. All rights reserved.
 */

#ifndef __KHOST_IPC_INF_APP_PERSON_DETECTION_H__
#define __KHOST_IPC_INF_APP_PERSON_DETECTION_H__

#include "khost_ipc_generic.h"
#include "khost_ipc_inf_app_tiny_yolo.h"

// Data structure is the same with tiny yolo.
typedef khost_ipc_inf_tiny_yolo_send_t khost_ipc_inf_pd_send_t;
typedef khost_ipc_inf_tiny_yolo_recv_t khost_ipc_inf_pd_recv_t;

#endif    //__KHOST_IPC_INF_APP_OBJECT_DETECTION_H__
