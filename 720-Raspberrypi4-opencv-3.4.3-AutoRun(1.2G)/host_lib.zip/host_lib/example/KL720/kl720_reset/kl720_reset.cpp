/**
 * @file        kl720_reset.cpp
 * @brief       kdp host lib user test examples
 * @version     0.1
 * @date        2020-12-10
 *
 * @copyright   Copyright (c) 2020-2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "user_util.h"
#include "kapp_id.h"
#include "model_res.h"
#include "model_type.h"
#include "base.h"
#include "ipc.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C"
{
#endif

int user_test_reset(int dev_idx, int mode, int scpu_log_level, int ncpu_log_level)
{
    int ret = 0;

    uint32_t reset_mode;
    
    if (mode == 0)
        reset_mode = 255;
    else if (mode == 1)
        reset_mode = 256;
    else if (mode == 2)
        reset_mode = 0x10000000 | (scpu_log_level & 0x0F) | (ncpu_log_level & 0x0F) << 8;
    else
        return -1;

    ret = kdp_reset_sys(dev_idx, reset_mode);
    if (ret != 0) {
        printf("could not reset sys: err %d\n", ret);
        return -1;
    }
    printf("sys reset mode succeeded...\n");

    return 0;
}

static void usage(char *name)
{
    printf("\n");
    printf("usage: ./%s [reset mode] [scpu log level] [ncpu log level]\n", name);
    printf("\n[reset mode] 0: reset, 1: shutdown, 2: log level\n");
    printf("[scpu log level] 1-6 = log level on SCPU\n");
    printf("[ncpu log level] 1-6 = log level on NCPU\n");
}

int main(int argc, char *argv[])
{
    int reset_mode, scpu_log_level, ncpu_log_level;

    if (argc < 2 || argc > 4) {
        usage(argv[0]);
        return -1;
    }

    reset_mode = atoi(argv[1]);
    if (reset_mode < 0 || reset_mode > 2) {
        usage(argv[0]);
        return -1;
    }

    if (reset_mode == 2) {
        if (argc < 4) {
            usage(argv[0]);
            return -1;
        }

        scpu_log_level = atoi(argv[2]);
        ncpu_log_level = atoi(argv[3]);
        if (scpu_log_level > 6 || ncpu_log_level > 6 || scpu_log_level < 1 || ncpu_log_level < 1) {
            printf("Error: log level out of range\n");
            usage(argv[0]);
            return -1;
        }
    }

    printf("init kdp host lib log....\n");

    if (kdp_lib_init() < 0)
    {
        printf("init for kdp host lib failed.\n");
        return -1;
    }

    printf("adding devices....\n");
    int dev_idx = kdp_connect_usb_device(1);
    if (dev_idx < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    printf("start kdp host lib....\n");
    if (kdp_lib_start() < 0)
    {
        printf("start kdp host lib failed.\n");
        return -1;
    }

    user_test_reset(dev_idx, reset_mode, scpu_log_level, ncpu_log_level);

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
