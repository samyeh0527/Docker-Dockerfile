/**
 * @file        kl720_isi_pdc.cpp
 * @brief       kdp host lib user test example
 * @version     0.2
 * @date        2021-4-5
 *
 * @copyright   Copyright (c) 2019-2021 Kneron Inc. All rights reserved.
 */


#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "user_util.h"
#include "post_processing_ex.h"
#include "kdpio.h"
#include "ipc.h"
#include "base.h"
#include "kapp_id.h"

#define USE_CV_TO_SHOW
#define BATCH_IMG_TEST 0

#if defined(USE_CV_TO_SHOW)
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <vector>
#endif

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
using namespace std;
#if defined(USE_CV_TO_SHOW)
using namespace cv;
#endif
#endif

#define NEF_FILE_2MODELS        ("../../input_models/KL720/yolov5_pd/models_720.nef")
#define MODEL_SIZE_2MODELS      (12 * 1024 * 1024)

const uint32_t model_ids[2] = {
    KNERON_PERSONDETECTION_YOLOV5sParklot_480_256_3,
    KNERON_PERSONCLASSIFIER_MB_56_32_3,
};
#define ISI_IMAGE_PATH      "../../input_images/"

#if BATCH_IMG_TEST
#define IMAGE_DATA_DIR (HOST_LIB_DIR "/input_images/640_480_bin")
#define IMG_WIDTH           640
#define IMG_HEIGHT          480
#elif 0
#define ISI_IMAGE_NAME      "4_16_43_1024x489_rgb565.bin"
#define IMG_WIDTH           1024
#define IMG_HEIGHT          489
#elif 0
#define ISI_IMAGE_NAME      "got_lannister_1920x1080_rgb565.bin"
#define IMG_WIDTH           1920
#define IMG_HEIGHT          1080
#else
#define ISI_IMAGE_NAME      "a_man_640x480_rgb565.bin"
//#define ISI_IMAGE_NAME      "twelve_persons_640x480_rgb565.bin"
#define IMG_WIDTH           640
#define IMG_HEIGHT          480
#endif

#define IMG_BPP             2       // Bytes Per Pixel
#define IMG_SIZE            (IMG_WIDTH * IMG_HEIGHT * IMG_BPP)

test_img_t* img_p;
#if BATCH_IMG_TEST
const char* image_file = IMAGE_DATA_DIR;
#else
const char* image_file = ISI_IMAGE_PATH ISI_IMAGE_NAME;
#endif

static char rgb_img[IMG_SIZE];
static char* img_buf = rgb_img;

#define MAX_NUM_BBOX            100
#define ISI_RESULT_SIZE         (((sizeof(bounding_box_t) + sizeof(bounding_box_t)) * MAX_NUM_BBOX) + 32)

static char inf_res[ISI_RESULT_SIZE] = {0};

static int use_parallel = 0;
static int run_frames;
static int video_mode = 0;
static int image_buf_size = 0;

static od_post_params_t post_proc_params_v5m = {
    .prob_thresh = 0.3,
    .nms_thresh = 0.45,
    .max_detection_per_class = 20,
    .anchor_row = 3,
    .anchor_col = 6,
    .stride_size = 3,
    .reserved_size = 0,
    .data = {
        // anchors[3][6]
        10, 13, 16, 30, 33, 23,
        30, 61, 62, 45, 59, 119,
        116, 90, 156, 198, 373, 326,
        // strides[3]
        8, 16, 32,
    },
};

#if defined(USE_CV_TO_SHOW)

#define VIDEO_IMAGE_W       (640)
#define VIDEO_IMAGE_H       (480)
#define VIDEO_IMG_SIZE      (VIDEO_IMAGE_W * VIDEO_IMAGE_H * IMG_BPP)

static VideoCapture cap;
static IplImage ipl_img;
vector<Mat> frames;

static char caption[160] = {0};
static char scores[50] = { 0 };

static int show_detection(char* image_data, int width, int height, char* win_name, char* inf_res)
{
    struct yolo_result_s* detection_res = (struct yolo_result_s*)inf_res;
    uint32_t box_count = detection_res->box_count;
    int pc_res_offset = 2 * sizeof(uint32_t) + box_count * sizeof(bounding_box_t);
    struct imagenet_result_s* pc_res_p = (struct imagenet_result_s*)(inf_res + pc_res_offset);

    Mat frame_show(height, width, CV_8UC3);

    if (video_mode) {
        frame_show = frames.front();
        cvtColor(frame_show, frame_show, CV_BGR5652BGR);
    }
    else {
        uint32_t* frame_data = (uint32_t*)(frame_show.data);
        kdp_cvt_color(frame_data, image_data, IMG_SIZE, RGB565_TO_BGR888);
    }

    struct bounding_box_s box;
    Scalar color;
    for (int i = 0; i < (int)box_count; i++) {
        box = detection_res->boxes[i];
        if (pc_res_p->index == 1 /*person*/) {
            color = Scalar(255, 0, 0);
            sprintf(scores, "[%d]=%.3f", i, pc_res_p->score);
        }
        else {
            color = Scalar(0, 255, 255);
            sprintf(scores, "[%d]=%.3f", i, 1.0 - pc_res_p->score);
        }
        rectangle(frame_show, Point(box.x1, box.y1), Point(box.x2, box.y2), color, 2);
        color = Scalar(0, 255, 255);
        putText(frame_show, scores, Point(box.x1, box.y1-8), FONT_HERSHEY_SIMPLEX, 0.4, color, 1);
        pc_res_p++;
    }

    namedWindow(win_name);
    moveWindow(win_name, 100, 0);
    imshow(win_name, frame_show);
    waitKey(1);

    if (video_mode) {
        // delete the first frame after showing detection
        vector<Mat>::iterator first_frame = frames.begin();
        frames.erase(first_frame);
    }

    return 0;
}
#endif

static int configure_isi_mode(int dev_idx)
{
    int ret;
    uint32_t error_code = 0;
    int model_size;
    char* p_buf;

    if (1) {
        int ret;

        p_buf = new char[MODEL_SIZE_2MODELS];
        if (p_buf == NULL) {
            printf("model buffer malloc failed\n");
            return -1;
        }
        ret = read_file_to_buf(p_buf, NEF_FILE_2MODELS, MODEL_SIZE_2MODELS);
        if (ret <= 0) {
            printf("reading model file failed: %d...\n", ret);
            delete[] p_buf;
            return ret;
        }
        model_size = ret;
    }

    char isi_init_data[1024];
    struct kdp_isi_start_s* isi_init;
    int cfg_size = sizeof(struct kdp_isi_start_s) + sizeof(struct kapp_isi_model_cfg_s);

    isi_init = (struct kdp_isi_start_s *)isi_init_data;
    memset(isi_init, 0, cfg_size);

    isi_init->app_id = APP_PDC;
    isi_init->compatible_cfg = 0;
    isi_init->start_flag = DOWNLOAD_MODEL | DEFAULT_CONFIG;
    isi_init->config.size = sizeof(struct kapp_isi_data_s) + sizeof(struct kapp_isi_model_cfg_s);
    isi_init->config.version = 0;
    isi_init->config.output_size = ISI_RESULT_SIZE;
    isi_init->config.config_block = 1;

    uint32_t format = IMAGE_FORMAT_SUB128 | NPU_FORMAT_RGB565 | IMAGE_FORMAT_CHANGE_ASPECT_RATIO;
    if (use_parallel)
        format |= IMAGE_FORMAT_PARALLEL_PROC;

    if (video_mode) {
        isi_init->config.m[0].img.image_col = VIDEO_IMAGE_W;
        isi_init->config.m[0].img.image_row = VIDEO_IMAGE_H;
    }
    else {
        isi_init->config.m[0].img.image_col = IMG_WIDTH;
        isi_init->config.m[0].img.image_row = IMG_HEIGHT;
    }
    isi_init->config.m[0].img.image_ch = 3;
    isi_init->config.m[0].img.image_format = format;
    memcpy((void*)isi_init->config.m[0].ext_param, (void*)&post_proc_params_v5m, MAX_PARAMS_LEN * sizeof(uint32_t));

    printf("Starting ISI mode and model loading ...\n");
    ret = kdp_start_isi_mode_ext2(dev_idx, (char*)isi_init, cfg_size, p_buf, model_size, &error_code, (uint32_t*)&image_buf_size);
    if (ret != 0)
    {
        printf("could not set to ISI mode: %d ..\n", ret);
        delete[] p_buf;
        return -1;
    }

    return 0;
}

static int load_image_files(int dev_idx, int img_no)
{
    int n_len;

#if defined(USE_CV_TO_SHOW)
    if (video_mode) {
        cap.open(0);

        cap.set(CV_CAP_PROP_FRAME_WIDTH, VIDEO_IMAGE_W);
        cap.set(CV_CAP_PROP_FRAME_HEIGHT, VIDEO_IMAGE_H);

        sprintf(caption, "Camera (%d x %d)", VIDEO_IMAGE_W, VIDEO_IMAGE_H);
        return 0;
    }
#endif

    sprintf(caption, "PDC Image (%d x %d)", IMG_WIDTH, IMG_HEIGHT);

    std::string new_fn_str(img_p[img_no].file_name);
    int idx = new_fn_str.find(".bin");
    if ((idx == -1) || (img_p[img_no].image_size != IMG_SIZE)) {
        printf("Image file is not %d*%d RGB565 binary\n", IMG_WIDTH, IMG_HEIGHT);
        return -1;
    }

    n_len = read_file_to_buf(img_buf, img_p[img_no].file_name, img_p[img_no].image_size);
    if (n_len <= 0) {
        printf("reading image file (%s) failed: %d\n", img_p[img_no].file_name, n_len);
        return -1;
    }

    return 0;
}

#if defined(USE_CV_TO_SHOW)
static int cam_capture_frame(VideoCapture cap)
{
    Mat frame_input;

    // capture a new frame from camera
    cap >> frame_input;

    cvtColor(frame_input, frame_input, CV_BGR2BGR565);

    // set mirror mode
    flip(frame_input, frame_input, 1);

    // Enqueue
    frames.push_back(frame_input);

    // return frame in IplImage format
#if CV_MAJOR_VERSION > 3 || (CV_MAJOR_VERSION == 3 && CV_SUBMINOR_VERSION >= 9)
    ipl_img = cvIplImage(frame_input);
#else
    ipl_img = (IplImage)frame_input;
#endif
    return 0;
}
#endif

static int do_inference(int dev_idx, uint32_t img_id, uint32_t* rsp_code, uint32_t* window_left, int file_no)
{
    int ret;

    if (video_mode) {
#if defined(USE_CV_TO_SHOW)
        cam_capture_frame(cap);
        img_buf = ipl_img.imageData;
        ret = kdp_isi_inference(dev_idx, img_buf, VIDEO_IMG_SIZE, img_id, rsp_code, window_left);
#endif
    }
    else {
        ret = kdp_isi_inference(dev_idx, img_buf, img_p[file_no].image_size, img_id, rsp_code, window_left);
    }

    if (ret)
    {
        printf("ISI inference failed : %d\n", ret);
        return -1;
    }
    if (*rsp_code != 0)
    {
        printf("ISI inference error_code: [%d] [%d]\n", *rsp_code, *window_left);
        return -1;
    }

    return 0;
}

static int get_detection_res(uint32_t img_id, uint32_t* r_size, char* r_data, int file_no)  // batch image test
{
    yolo_result_s* detection_res;
    struct imagenet_result_s* imgnet_res;
    int ret = 0;
    int i, box_count;
    float person_classifier_score;
    char out_buf[4096] = {0};
	uint32_t off = 0;	

    detection_res = (yolo_result_s*)r_data;
    box_count = detection_res->box_count;
    imgnet_res = (struct imagenet_result_s*)(r_data + 8 + box_count * sizeof(bounding_box_t));

    printf("\nimage %d: box_count %d class_count %d\n", img_id, box_count, detection_res->class_count);
    sprintf(out_buf + off,"\nimage %d:\r\n box_count %d class_count %d\n", img_id, box_count, detection_res->class_count); 
	off = strlen(out_buf);
    for (i = 0; i < box_count; i++) {
        if (imgnet_res->index == 1)
            person_classifier_score = imgnet_res->score;
        else
            person_classifier_score = 1.0 - imgnet_res->score;
        printf("[%d] person=%d: (%3d, %3d, %3d, %3d) scores = %f / %f\n", i, imgnet_res->index,
            (int)detection_res->boxes[i].x1, (int)detection_res->boxes[i].y1,
            (int)detection_res->boxes[i].x2, (int)detection_res->boxes[i].y2,
            detection_res->boxes[i].score, person_classifier_score);
        sprintf(out_buf + off, "[%d] person=%d: (%3d, %3d, %3d, %3d) scores = %f / %f\n",  i, imgnet_res->index,
            (int)detection_res->boxes[i].x1, (int)detection_res->boxes[i].y1, 
            (int)detection_res->boxes[i].x2, (int)detection_res->boxes[i].y2, 
             detection_res->boxes[i].score, person_classifier_score);	
             off = strlen(out_buf); 					
        imgnet_res++;
    }

#if defined(USE_CV_TO_SHOW)
    if (video_mode) {
        show_detection(img_buf, VIDEO_IMAGE_W, VIDEO_IMAGE_H, caption, r_data);
    }
    else {
        show_detection(img_buf, IMG_WIDTH, IMG_HEIGHT, caption, r_data);
    }
#endif
    if (video_mode == 0 && img_id == 1) {
        off = strlen(out_buf);
        ret = export_result_to_file(out_buf, off, img_p[file_no].file_name, NULL);
	}
    return ret;
}

static int do_get_result(int dev_idx, uint32_t img_id, uint32_t* rsp_code, uint32_t* r_size, char* r_data, int file_no)
{
    int ret;

    memset(r_data, 0, 8); // initialize results data

    ret = kdp_isi_retrieve_res(dev_idx, img_id, rsp_code, r_size, r_data);
    if (ret)
    {
        printf("ISI get [%d] result failed : %d\n", img_id, ret);
        return -1;
    }

    if (*rsp_code != 0)
    {
        printf("ISI get [%d] result error_code: [%d] [%d]\n", img_id, *rsp_code, *r_size);
        return -1;
    }

    if (*r_size < sizeof(uint32_t) || *r_size > ISI_RESULT_SIZE) {
        printf("Img [%d] : wrong result size %d\n", img_id, *r_size);
        return -1;
    }
    ret = get_detection_res(img_id, r_size, r_data, file_no);
    return ret;
}

static int user_test_isi_pdc(int dev_idx, int file_no)
{
    int ret;
    uint32_t error_code = 0;

    ret = configure_isi_mode(dev_idx);
    if (ret)
        return ret;

    ret = load_image_files(dev_idx, file_no);
    if (ret)
        return ret;

    if (1) {

        printf("starting ISI inference (window = %d)\n", image_buf_size);
        uint32_t img_id_tx, img_id_rx;
        uint32_t img_left;
        uint32_t result_size = ISI_RESULT_SIZE;

        int ret;
        int loop_end;
        int tx_loop, rx_loop;

        double start_time = what_time_is_it_now();

        loop_end = run_frames;
        if (loop_end < image_buf_size - 1)
            use_parallel = 0;

        tx_loop = rx_loop = 0;
        img_id_rx = img_id_tx = 1;

        while (tx_loop < loop_end || rx_loop < loop_end) {
            if (check_ctl_break()) {
                printf("Ctrl-C received. Exit.\n");
                loop_end = tx_loop;
            }

            if (tx_loop < loop_end) {
                ret = do_inference(dev_idx, img_id_tx, &error_code, &img_left, file_no);
                if (ret)
                    return ret;
                img_id_tx++;
                tx_loop++;
            }

            if (use_parallel && tx_loop < (image_buf_size - 1))
                continue;

            if (rx_loop < loop_end) {
                ret = do_get_result(dev_idx, img_id_rx, &error_code, &result_size, inf_res, file_no);
                if (ret)
                    return ret;
                img_id_rx++;
                rx_loop++;
            }
        }

        if (1)
        {
            double end_time = what_time_is_it_now();
            double elapsed_time, avg_elapsed_time, avg_fps;
            uint32_t actual_loop = loop_end;

            elapsed_time = (end_time - start_time) * 1000;
            avg_elapsed_time = elapsed_time / actual_loop;
            avg_fps = 1000.0f / avg_elapsed_time;

            printf("\n=> Avg %.2f FPS (%.2f ms = %.2f/%d)\n\n",
                avg_fps, avg_elapsed_time, elapsed_time, actual_loop);
        }
    }
    return 0;
}

static void usage(char* name)
{
    printf("\n");
    printf("usage: ./%s  [video_mode] [run_frames] [test img | batch_test_dir]\n\n", name);
    printf("[video_mode] 0: image mode, 1: video mode\n");
    printf("[run_frames] number of frames (> 0) to run\n");
	printf("[test img | batch_test_dir] image name or img dir for Width*Height(%d*%d) RGB565 binary file\n", IMG_WIDTH, IMG_HEIGHT);
}

int main(int argc, char* argv[])
{
    if (argc < 3 || argc > 4) {
        printf("Error: Incorrect argument number\n");
        usage(argv[0]);
        return -1;
    }

    video_mode = atoi(argv[1]);
    if (video_mode && video_mode != 1) {
        printf("Error: Incorrect video_mode %d\n", video_mode);
        usage(argv[0]);
        return -1;
    }

    run_frames = atoi(argv[2]);
    if (run_frames <= 0) {
        printf("Error: Incorrect run_frames %d\n", run_frames);
        usage(argv[0]);
        return -1;
    }

#if !defined(USE_CV_TO_SHOW)
    if (video_mode) {
        printf("\n* Please enable USE_CV_TO_SHOW to use video_mode *\n\n");
        return -1;
    }
#endif

    printf("init kdp host lib log....\n");

    if (kdp_lib_init() < 0)
    {
        printf("init for kdp host lib failed.\n");
        return -1;
    }

    printf("adding devices....\n");
    int dev_idx = kdp_connect_usb_device(1);
    if (dev_idx < 0)
    {
        printf("add device failed.\n");
        return -1;
    }

    printf("start kdp host lib....\n");
    if (kdp_lib_start() < 0)
    {
        printf("start kdp host lib failed.\n");
        return -1;
    }

    register_hostlib_signal();

    if (video_mode) {
        use_parallel = 0;
        printf("test video mode\r\n");
        user_test_isi_pdc(dev_idx, 0);
    }
    else {
        char* test_img_dir = NULL;
        int total_files = 0;

        if (argc == 4)
            test_img_dir = argv[3];

        if (test_img_dir == NULL)
            test_img_dir = (char*)image_file;

        use_parallel = 1;
        img_p = create_batch_image_file_list(test_img_dir, &total_files);
        if (NULL == img_p) {
            printf(" image file %s is not found\n\r", test_img_dir);
        }
        for (int i = 0; i < total_files; i++) {
            printf("test image %s, size is 0x%x, file no is %d\r\n", img_p[i].file_name, img_p[i].image_size, i);
            user_test_isi_pdc(dev_idx, i);
        }
    }

    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
