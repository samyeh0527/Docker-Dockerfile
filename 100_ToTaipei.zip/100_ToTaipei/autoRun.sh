#!/bin/sh

cd /Desktop/100_ToTaipei/host_lib/build/bin
./kl520_dme_yolo_multiple_dongles



cd /Desktop/100_ToTaipei/host_lib/

python3 updateJson.py