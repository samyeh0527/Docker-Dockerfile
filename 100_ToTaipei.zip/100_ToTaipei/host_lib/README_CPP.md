# Kneron Host Lib

This project contains C++ examples for using Kneron edge devices

This is a brief introduction. For more detailed documents, please visit <http://doc.kneron.com/docs>.

## Environment Requirements
### Linux
- install libusb
    `sudo apt install libusb-1.0-0-dev`

### Windows(MINGW64/MSYS)
- environment, gcc, etc.
    - get [git for windows SDK (MUST BE!)](https://gitforwindows.org/) installed
- install libusb
    `pacman -S mingw-w64-x86_64-libusb`
- install cmake
    `pacman --needed -S mingw-w64-x86_64-cmake`
    
    > make sure you are using `/mingw64/bin/cmake`
- install opencv 3.4.X
    `pacman -U mingw-w64-x86_64-opencv-3.4.1-1-any.pkg.tar.xz` 
    >  For the prebuilt package, please visit <http://kneron.com/tw/support/developers> and download **opencv 3.4.1* 
    >  Alternately, you can follow instructions by opencv.org to build from source`

## Build
### Linux
```bash
mkdir build && cd build
# to build opencv_3.4 example: cmake -DBUILD_OPENCV_EX=on ..
cmake ..

# after makefiles are generated, you can choose one of followings to make
make -j4 		# to build libhostkdp and all examples
```

### Windows(MINGW64/MSYS)
```bash
mkdir build && cd build
# to build opencv_3.4 example: cmake -G"MSYS Makefiles" -DBUILD_OPENCV_EX=on ..
cmake .. -G"MSYS Makefiles"

# after makefiles are generated, you can choose one of followings to make
make -j4 		# to build libhostkdp and all examples
```

## Output Bin Files
``host_lib/build/bin/*``

