/**
 * @file        async_test.h
 * @brief       kdp host lib async test header file
 * @version     0.1
 * @date        2019-04-23
 *
 * @copyright   Copyright (c) 2019-2021 Kneron Inc. All rights reserved.
 */


#ifndef __ASYNC_TEST__H__
#define __ASYNC_TEST__H__

int async_test(int dev_idx);

#endif

