/**
 * @file        delay.h
 * @brief       Kneron Delay driver
 * @version     0.1
 * @date        2021-03-22
 *
 * @copyright   Copyright (c) 2019-2021 Kneron Inc. All rights reserved.
 */

#ifndef __DELAY_H__
#define __DELAY_H__

/**
 * @brief microseconds delay for any cpu
 *
 * @param [in] usec number of microseconds
 * @return No
 */
void delay_us(unsigned int usec);

#endif
