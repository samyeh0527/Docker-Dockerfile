import os
from time import sleep
import time
from datetime import datetime
import json
import csv



def json_file_write(people_count, mask_cnt):
	gm_time = time.gmtime()
	transfer_time_stamp = time.mktime(gm_time)
	formatted_datetime = int(transfer_time_stamp)
	
	data = {
        "timestamp": formatted_datetime,
        "people_count": people_count,
        "mask_people": mask_cnt
    }
    
	json_data = json.dumps(data)
	print('json_data : ', json_data)
	#### save json file to folder ####
	with open(folderName + 'AIVideo_RealTimeImage.json', "w+") as f:
		json.dump(data, f)
	return(json_data)



folderName = "//tmp/"
detectResultPath = "./output_csv/detectionResult.csv"

# ~ Mars example:
# ~ people_count = 3
# ~ mask_cnt = 2
# ~ json_file_write(people_count, mask_cnt)



with open(detectResultPath) as csvFile:
	csvReader = csv.reader(csvFile)
	detectResults = list(csvReader)

# ~ first row is title
detectResults = detectResults[1:]	


for detectResult in detectResults:
	jsonFiles = os.listdir(folderName)
	# ~ print(jsonFiles)
	while "AIVideo_RealTimeImage.json" in jsonFiles:
		jsonFiles = os.listdir(folderName)
		sleep(0.5)
		print("wait...")
	
	json_file_write(int(detectResult[0]), int(detectResult[1]))



	
print("OK")

