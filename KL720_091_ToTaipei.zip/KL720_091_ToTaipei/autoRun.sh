#!/bin/sh

cd /Desktop/KL720_091_ToTaipei/host_lib/build/bin
./saveCsv_NJ_kl720_dme_serial_yolo



cd /Desktop/KL720_091_ToTaipei/host_lib/

./updateJson.py