/**
 * @file      user_test_dme.cpp for KL720
 * @brief     kdp host lib user test examples 
 * @version   0.2 - 2020-10-01
 * @copyright (c) 2019-2020 Kneron Inc. All right reserved.
 */

#include "errno.h"
#include "kdp_host.h"
#include "stdio.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <glob.h>
#include <dirent.h>
#include <cstring>

#include "user_util.h"
#include "post_processing_ex.h"
#include "kdpio.h"
#include "ipc.h"
#include "base.h"


#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <vector>

#include <fstream>


extern "C" {
uint32_t round_up(uint32_t num);
int post_yolo_v3(int model_id, struct kdp_image_s *image_p);
int NJ_post_yolo_v3(int model_id, struct kdp_image_s *image_p, struct yolo_result_s *result);
}

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
    
using namespace std;
using namespace cv;
    
#endif


//~ #define DME_MODEL_FILE      ("../../input_models/KL720/yolov3_tiny_416/models_720.nef")
//~ #define CLASS_LABEL_FILE    ("../../input_label/coco.names")    

#define DME_MODEL_FILE      ("../../input_models/KL720/yolov3_tiny_416/models_720_mask.nef")
#define CLASS_LABEL_FILE    ("../../input_label/coco_mask.names")    


/* Model input dimension : Tiny Yolo 416 */
#define IMG_FORMAT          (NPU_FORMAT_RGB565 | IMAGE_FORMAT_SUB128)

#define DME_MODEL_SIZE      (12 * 1024 * 1024)
#define DME_FWINFO_SIZE     128

char inf_res_raw[768000];



//~ NJ
#define BMP_IMG_FILE ("../../input_images/rpi-kl720-testImg/woman_ballon_1.bmp")
//~ #define BMP_IMG_FILE ("../../input_images/rpi-kl720-testImg/testImg.bmp")
#define BMP_IMG_FILE_RES ("../../output_images/woman_ballon_1.bmp")
#define CSV_FILE_RES ("../../output_csv/mask.csv")

#define IMG_FOLDER ("../../input_images/rpi-kl720-testImg/")


int bmpWidth, bmpHeight;
char *bmpImgBuf = NULL;
uint32_t bmpModelId = 0;
vector<string> classes;
vector<string> imageNames;
char *currentImageName;
FILE *fpt;


void NJ_setClass()
{
    string classesFile = CLASS_LABEL_FILE;
    ifstream ifs(classesFile.c_str());
    string line;
    while (getline(ifs, line)) 
        classes.push_back(line);
}

void get_detection_res_raw(int dev_idx, uint32_t inf_size, struct post_parameter_s post_par)
{
    // Get the data for all output nodes: TOTAL_OUT_NUMBER + (H/C/W/RADIX/SCALE) + (H/C/W/RADIX/SCALE) + ...
    // + FP_DATA + FP_DATA + ...
    raw_cnn_res_t *pRes;
    raw_onode_t *pNode;
    kdp_dme_retrieve_res(dev_idx, 0, inf_size, inf_res_raw);

    // Prepare for postprocessing
    pRes = (raw_cnn_res_t *)inf_res_raw;
    int output_num = pRes->total_nodes;

    uint32_t r_len, offset;
    struct yolo_result_s *det_res = (struct yolo_result_s *)calloc(1, sizeof(dme_yolo_res));
    struct kdp_image_s *image_p = (struct kdp_image_s *)calloc(1, sizeof(struct kdp_image_s));
    offset = sizeof(raw_cnn_res_t);

    // Struct to pass the parameters
    RAW_INPUT_COL(image_p) = post_par.raw_input_col;
    RAW_INPUT_ROW(image_p) = post_par.raw_input_row;
    DIM_INPUT_COL(image_p) = post_par.model_input_row;
    DIM_INPUT_ROW(image_p) = post_par.model_input_row;
    RAW_FORMAT(image_p) = post_par.image_format;
    POSTPROC_RESULT_MEM_ADDR(image_p) = (uint32_t *)det_res;
    POSTPROC_OUTPUT_NUM(image_p) = output_num;

    for (int i = 0; i < output_num; i++) {
        if (check_ctl_break())
            return;
        pNode = &pRes->onode_a[i];
        r_len = pNode->ch_length * pNode->row_length  * round_up(pNode->col_length);
        POSTPROC_OUT_NODE_ADDR(image_p, i) = inf_res_raw + offset;
        POSTPROC_OUT_NODE_ROW(image_p, i) = pNode->row_length;
        POSTPROC_OUT_NODE_CH(image_p, i) = pNode->ch_length;
        POSTPROC_OUT_NODE_COL(image_p, i) = pNode->col_length;
        POSTPROC_OUT_NODE_RADIX(image_p, i) = pNode->output_radix;
        POSTPROC_OUT_NODE_SCALE(image_p, i) = pNode->output_scale;
        offset = offset + r_len;
    }

    // Do postprocessing   
    //~ post_yolo_v3(0, image_p);
    
    struct yolo_result_s *result;
    result = (struct yolo_result_s *)(POSTPROC_RESULT_MEM_ADDR(image_p));
    NJ_post_yolo_v3(0, image_p, result);
    printf("NJ!!!! count: %d\n", result->box_count);

    int maskCount = 0;
    int badCount = 0;
    
    Scalar color;
    Mat bmpImg;
    bmpImg = imread(BMP_IMG_FILE, CV_LOAD_IMAGE_COLOR);
    
    for (int i = 0; i < (int)result->box_count; i++) {
        if (result->boxes[i].class_num == 0 /*person*/) {
            color = Scalar(255, 0, 0);
            maskCount++;
        }else {
            badCount++;
            color = Scalar(0, 255, 0);
        }
            
        printf("post_yolo3[%d] (%d, %d, %d, %d) %f %d\n", i, (int)result->boxes[i].x1, (int)result->boxes[i].y1, (int)result->boxes[i].x2, (int)result->boxes[i].y2, result->boxes[i].score, result->boxes[i].class_num);
        
        rectangle(bmpImg, Point(result->boxes[i].x1, result->boxes[i].y1), Point(result->boxes[i].x2, result->boxes[i].y2), color, 2);
        
        string label = format(" %.2f", result->boxes[i].score);
        label = classes[result->boxes[i].class_num] + label;
        putText(bmpImg, label, Point(result->boxes[i].x1, result->boxes[i].y1 + 20), FONT_HERSHEY_SIMPLEX, 0.75, color,2);

    }
    
    imwrite(BMP_IMG_FILE_RES, bmpImg);
    
    /* get seconds since the Epoch */
    time_t secs = time(0);

    /* convert to localtime */
    struct tm *local = localtime(&secs);

    /* and set the string */
    //~ printf("%04d/%02d/%02d %02d:%02d:%02d", 1900 + local->tm_year, 1 + local->tm_mon,local->tm_mday,local->tm_hour, local->tm_min, local->tm_sec);
    
    
    fprintf(fpt, "%d, %d, %04d/%02d/%02d %02d:%02d:%02d\n", 
            maskCount + badCount, 
            maskCount, 
            1900 + local->tm_year, 1 + local->tm_mon,local->tm_mday,local->tm_hour, local->tm_min, local->tm_sec);

    free(image_p);
    free(det_res);
    
    //~ NJ what's difference between free and NUll ????
    //~ result = NULL;
    //~ if (result) printf("whyyyy not NULL !!!\n");
}


int user_test(int dev_idx, int user_id)
{
    //~ Step1.
    //~ load model
    uint32_t model_size = 0;
    int ret;
    char* p_buf = NULL;

    // read model file
    p_buf = new char[DME_MODEL_SIZE];
    memset(p_buf, 0, DME_MODEL_SIZE);
    ret = read_file_to_buf(p_buf, DME_MODEL_FILE, DME_MODEL_SIZE);
    if (ret <= 0) {
        printf("reading model file failed:%d...\n", ret);
        delete[] p_buf;
        exit(1);
    }
    model_size = ret;


    printf("starting DME inference in [serial mode] ...\n");
    uint32_t ret_size = 0;
    ret = kdp_start_dme_ext(dev_idx, p_buf, model_size, &ret_size);
    if (ret != 0) {
        printf("could not set to DME mode:%d..\n", model_size);
        delete[] p_buf;
        exit(1);
    }

    delete[] p_buf;
    printf("DME mode succeeded...\n");
    usleep(SLEEP_TIME);
    // --------------------------------------------- //
       
    
    printf("dev_id: %d, user_id: %d", dev_idx, user_id);
    NJ_setClass();
    fpt = fopen(CSV_FILE_RES, "w+");
    fprintf(fpt, "totalCount, maskCount, time\n");
    
    
    DIR *di;
    char *ptr1,*ptr2;
    int retn;
    struct dirent *dir;
    di = opendir(IMG_FOLDER); //specify the directory name
    if (di){
        while ((dir = readdir(di)) != NULL){
            ptr1=strtok(dir->d_name,".");
            ptr2=strtok(NULL,".");
            if(ptr2!=NULL){
                retn=strcmp(ptr2,"bmp");
                if(retn==0){
                    printf("%s\t",ptr1);
                    
                    //~ Step2. Load image file (.bmp)
                    //~ load .bmp, convert to rgb565(bin) 
                    //~ bmpImgBuf = bmp_to_rgb565_auto_malloc(BMP_IMG_FILE, &bmpWidth, &bmpHeight);
                    
                    
                    char path[50];
                    strcpy(path, IMG_FOLDER);
                    strcat(path, ptr1);
                    strcat(path, ".bmp");
                    printf("\n%s\n", path);
                    
                    

                    bmpImgBuf = bmp_to_rgb565_auto_malloc(path, &bmpWidth, &bmpHeight);


                    printf("input image shape(w: %d, h: %d)\n", bmpWidth, bmpHeight);
                    uint32_t bmpImgBuffLen = bmpWidth * bmpHeight * 2; //RGB565 (copy form 520)
                    
                    //~ Step3. dme configuration
                    struct kdp_dme_cfg_s dme_cfg;
                    memset(&dme_cfg, 0, sizeof(kdp_dme_cfg_s));
                    
                    //~ dme_cfg.model_id = TINY_YOLO_V3_416_416_3; // model id when compiling in toolchain
                    dme_cfg.model_id = 1000; // model id when compiling in toolchain
                    dme_cfg.output_num = 20;           // number of output node for the model
                    dme_cfg.image_col = bmpWidth;
                    dme_cfg.image_row = bmpHeight;
                    dme_cfg.image_ch = 3;
                    dme_cfg.image_format = IMG_FORMAT | IMAGE_FORMAT_RAW_OUTPUT;
                    

                    uint32_t dat_size;
                    dat_size = sizeof(struct kdp_dme_cfg_s);
                    printf("starting DME configure ...\n");
                    ret = kdp_dme_configure(dev_idx, (char *)&dme_cfg, dat_size, &bmpModelId);

                    if (ret != 0) {
                        printf("could not set to DME configure mode..\n");
                        exit(1);
                    }
                    printf("DME configure model[%d] succeeded...\n", bmpModelId);
                    usleep(SLEEP_TIME);
                    
                    //~ Step4. do inference
                    uint32_t inf_size = 0;
                    char inf_res[256000];
                    bool res_flag = true;
                    
                    double start;
                    float fps = 0;
                    int loop = 1;
                        
                    printf("starting DME inference for [%d] times ...\n", loop);
                    
                    
                    struct post_parameter_s post_par;
                    // parameters for postprocessing: raw fp results and postprocess in host
                    post_par.raw_input_row   = bmpHeight;
                    post_par.raw_input_col   = bmpWidth;
                    post_par.model_input_row = 416;
                    post_par.model_input_col = 416;
                    post_par.image_format    = IMG_FORMAT | IMAGE_FORMAT_RAW_OUTPUT;
                    
                    start = what_time_is_it_now();
                    for (int i = 0; i < loop; i++) {
                        if (check_ctl_break()) exit(1);
                            
                        int ret = kdp_dme_inference(dev_idx, bmpImgBuf, bmpImgBuffLen, &inf_size, &res_flag, inf_res, 0, bmpModelId);

                        if (ret != 0) {
                            printf("could not set to DME inference mode..\n");
                            exit(1);
                        }
                        
                        printf("Image %d: Postprocess on host\n", i + 1);
                        get_detection_res_raw(dev_idx, inf_size, post_par);
                        
                            
                        if (check_ctl_break())
                            exit(1);
                    }
                    fps = 1./((what_time_is_it_now() - start)/loop);
                    printf("\naverage time on 100 frames: %f ms/frame, fps: %f\n", (1/fps)*1000, fps);

                    printf("DME inference succeeded...\n");
                    
                    free(bmpImgBuf);
                    
                }
            }
        }
        closedir(di);
    }
    
    
    
    kdp_end_dme(dev_idx); // TODO: make reset in kdp_end_dme work on 720
    
    fclose(fpt);
    return 0;
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
